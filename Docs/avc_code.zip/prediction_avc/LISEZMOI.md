# Classification du risque d'AVC — notebook Python

Travail pratique universitaire (EIJV, 2026) : exploration des données, préparation,
comparaison de modèles de classification (régression logistique, Random Forest, KNN),
gestion du déséquilibre de classes (pondération, SMOTE) et réglage du seuil de décision.

## Lancer le notebook

1. Installer les dépendances : `pip install -r requirements.txt`
2. Télécharger le fichier `healthcare-dataset-stroke-data.csv` depuis Kaggle
   (« Stroke Prediction Dataset ») :
   https://www.kaggle.com/datasets/fedesoriano/stroke-prediction-dataset
3. Placer le fichier CSV dans ce dossier, à côté du notebook.
4. Lancer `jupyter notebook prediction_avc.ipynb`.

Le jeu de données n'est pas inclus ici : il reste disponible à sa source d'origine.

## À propos du jeu de données

L'origine de ce jeu de données n'est pas documentée : on ne sait ni où, ni quand,
ni comment les données ont été collectées, ni s'il s'agit de vrais patients.
Une étude publiée dans BMC Medicine en 2026 (Gibson, Barnett et al.) l'a signalé
pour ce manque de traçabilité. Il convient donc à un exercice d'apprentissage
des méthodes, mais pas à l'élaboration d'un modèle destiné à la pratique clinique.

Base de données hospitalière — projet universitaire (EIJV, 2025-2026)
Projet réalisé en groupe de trois. Les données sont des données d'exemple, non réelles.

MODÈLE
- MCD.png : modèle conceptuel de données (MERISE)
- MLD.txt : modèle logique de données (14 entités et 6 tables d'association)

VERSION SQL (base « hopital », syntaxe de type MySQL / MariaDB : AUTO_INCREMENT, ENUM, DATE_SUB / CURDATE)
1. hopital.sql           : création de la base et des 20 tables, avec clés et contraintes
2. hopital_data.sql      : insertion des données d'exemple
3. hopital_requetes.sql  : requêtes d'exploitation (jointures, agrégations, tris)

VERSION MONGODB (base « hopital_nosql »)
1. hopital.js            : création des collections
2. hopital_data.js       : insertion des documents d'exemple (parcours de soins imbriqués dans les patients)
3. hopital_requete.js    : requêtes d'interrogation (find, projections)

Exécuter les scripts dans l'ordre indiqué.

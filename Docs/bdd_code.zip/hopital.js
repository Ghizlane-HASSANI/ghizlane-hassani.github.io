
use("hopital_nosql")
db.createCollection("patients");
db.createCollection("etablissements");
db.createCollection("personnels");
db.createCollection("medicaments");
create database hopital;
use hopital;

create table etablissements (
    id_etablissement int auto_increment,
    nom varchar(100) not null,
    adresse varchar(255) not null,
    telephone varchar(15) not null,
    type_etablissement enum('public', 'prive') not null,
    categorie enum('hopital', 'clinique', 'centre de sante') not null,
    constraint pk_etablissement primary key (id_etablissement)
);

create table services (
    id_service int auto_increment,
    nom varchar(100) not null,
    etablissement_id int not null,
    constraint pk_service primary key (id_service),
    constraint fk_service_etablissement foreign key (etablissement_id) references etablissements(id_etablissement)
        on delete cascade
        on update cascade
);

create table personnels (
    id_personnel int auto_increment,
    nom varchar(100) not null,
    prenom varchar(100) not null,
    specialite varchar(100),
    categorie enum('soignant', 'administratif', 'entretien', 'technique') not null,
    constraint pk_personnel primary key (id_personnel)
);

create table services_personnels (
    service_id int not null,
    personnel_id int not null,
    constraint pk_services_personnels primary key (service_id, personnel_id),
    constraint fk_services_personnels_service foreign key (service_id) references services(id_service)
        on delete cascade
        on update cascade,
    constraint fk_services_personnels_personnel foreign key (personnel_id) references personnels(id_personnel)
        on delete cascade
        on update cascade
);

create table patients (
    id_patient int auto_increment,
    nom varchar(100) not null,
    prenom varchar(100) not null,
    date_naissance date not null,
    adresse varchar(255),
    telephone varchar(15),
    mail varchar(100),
    constraint pk_patient primary key (id_patient)
);

create table parcours_soins (
    id_parcours int auto_increment,
    date_entree datetime not null,
    date_sortie datetime,
    patient_id int not null,
    constraint pk_parcours primary key (id_parcours),
    constraint fk_parcours_patient foreign key (patient_id) references patients(id_patient)
        on delete cascade
        on update cascade
);

create table rendez_vous (
    id_rendez_vous int auto_increment,
    date_rendez_vous datetime not null,
    motif varchar(255),
    patient_id int not null,
    personnel_id int not null,
    parcours_id int,
    constraint pk_rendez_vous primary key (id_rendez_vous),
    constraint fk_rendez_vous_patient foreign key (patient_id) references patients(id_patient)
        on delete cascade
        on update cascade,
    constraint fk_rendez_vous_personnel foreign key (personnel_id) references personnels(id_personnel)
        on delete cascade
        on update cascade,
    constraint fk_rendez_vous_parcours foreign key (parcours_id) references parcours_soins(id_parcours)
        on delete cascade
        on update cascade
);

create table diagnostics (
    id_diagnostic int auto_increment,
    description varchar(500) not null,
    rendez_vous_id int not null,
    constraint pk_diagnostic primary key (id_diagnostic),
    constraint fk_diagnostic_rendez_vous foreign key (rendez_vous_id) references rendez_vous(id_rendez_vous)
        on delete cascade
        on update cascade
);

create table traitements (
    id_traitement int auto_increment,
    description varchar(500) not null,
    constraint pk_traitement primary key (id_traitement),
);

create table medicaments (
    id_medicament int auto_increment,
    nom varchar(100) not null,
    description varchar(500),
    laboratoire varchar(100),
    constraint pk_medicament primary key (id_medicament)
);

create table traitements_medicaments(
    traitement_id int not null,
    medicament_id int not null,
    posologie varchar(255) not null,
    constraint pk_traitements_medicaments primary key (traitement_id, medicament_id),
    constraint fk_traitements_medicaments_traitement foreign key (traitement_id) references traitements(id_traitement)
        on delete cascade
        on update cascade,
    constraint fk_traitements_medicaments_medicament foreign key (medicament_id) references medicaments(id_medicament)
        on delete cascade
        on update cascade
);

create table patients_traitements(
    patient_id int not null,
    traitement_id int not null,
    constraint pk_patients_traitements primary key (patient_id, traitement_id),
    constraint fk_patients_traitements_patient foreign key (patient_id) references patients(id_patient)
        on delete cascade
        on update cascade,
    constraint fk_patients_traitements_traitement foreign key (traitement_id) references traitements(id_traitement)
        on delete cascade
        on update cascade
);


create table pathologies (
    id_pathologie int auto_increment,
    nom varchar(100) not null,
    description varchar(500),
    constraint pk_pathologie primary key (id_pathologie)
);

create table traitements_pathologies (
    traitement_id int not null,
    pathologie_id int not null,
    constraint pk_traitements_pathologies primary key (traitement_id, pathologie_id),
    constraint fk_tp_traitement foreign key (traitement_id) references traitements(id_traitement)
        on delete cascade
        on update cascade,
    constraint fk_tp_pathologie foreign key (pathologie_id) references pathologies(id_pathologie)
        on delete cascade
        on update cascade
);

create table patients_pathologies(
    patient_id int not null,
    pathologie_id int not null,
    constraint pk_patients_pathologies primary key (patient_id, pathologie_id),
    constraint fk_patients_pathologies_patient foreign key (patient_id) references patients(id_patient)
        on delete cascade
        on update cascade,
    constraint fk_patients_pathologies_pathologie foreign key (pathologie_id) references pathologies(id_pathologie)
        on delete cascade
        on update cascade
);

create table constantes(
    id_constante int auto_increment,
    valeur float not null,
    type_constante enum('temperature (°C)', 'tension (mmHg)', 'frequence cardiaque (bpm)', 'frequence respiratoire (rpm)') not null,
    date_enregistrement datetime not null,
    patient_id int not null,
    constraint pk_constante primary key (id_constante),
    constraint fk_constante_patient foreign key (patient_id) references patients(id_patient)
        on delete cascade
        on update cascade
);


create table actes_medicaux (
    id_acte_medical int auto_increment,
    description varchar(500) not null,
    date_prevu datetime not null,
    service_id int not null,
    parcours_id int not null,
    constraint pk_acte_medical primary key (id_acte_medical),
    constraint fk_acte_medical_service foreign key (service_id) references services(id_service)
        on delete cascade
        on update cascade,
    constraint fk_acte_medical_parcours foreign key (parcours_id) references parcours_soins(id_parcours)
        on delete cascade
        on update cascade
);

create table actes_personnels (
    acte_medical_id int not null,
    personnel_id int not null,
    constraint pk_actes_personnels primary key (acte_medical_id, personnel_id),
    constraint fk_actes_personnels_acte_medical foreign key (acte_medical_id) references actes_medicaux(id_acte_medical)
        on delete cascade
        on update cascade,
    constraint fk_actes_personnels_personnel foreign key (personnel_id) references personnels(id_personnel)
        on delete cascade
        on update cascade
);

create table machines(
    id_machine int auto_increment,
    type_machine varchar(100) not null,
    date_achat date not null,
    date_mise_service date,
    date_derniere_maintenance date,
    service_id int not null,
    constraint pk_machine primary key (id_machine),
    constraint fk_machine_service foreign key (service_id) references services(id_service)
        on delete cascade
        on update cascade
);

create table maintenances(
    id_maintenance int auto_increment,
    date_maintenance date not null,
    description varchar(500),
    machine_id int not null,
    constraint pk_maintenance primary key (id_maintenance),
    constraint fk_maintenance_machine foreign key (machine_id) references machines(id_machine)
        on delete cascade
        on update cascade
);
db.etablissements.insertMany([
  {
    _id: 1,
    nom: "CHU de Lille",
    adresse: "2 avenue Oscar Lambret, Lille",
    telephone: "0320445000",
    type: "public",
    categorie: "hopital",
    services: [
      {
        id_service: 1,
        nom: "Urgences",
        machines: [
          {
            type: "Respirateur",
            date_achat: new Date("2021-02-12"),
            maintenances: [
              { date: new Date("2024-03-15"), description: "Révision respirateur" }
            ]
          }
        ]
      },
      {
        id_service: 2,
        nom: "Cardiologie",
        machines: [
          {
            type: "Moniteur cardiaque",
            date_achat: new Date("2022-05-01"),
            maintenances: [
              { date: new Date("2024-04-05"), description: "Calibration moniteur" }
            ]
          }
        ]
      }
    ]
  },

  {
    _id: 2,
    nom: "CH d’Amiens",
    adresse: "1 rue du Professeur Christian Cabrol, Amiens",
    telephone: "0322088000",
    type: "public",
    categorie: "hopital",
    services: [
      {
        id_service: 3,
        nom: "Pédiatrie",
        machines: [
          {
            type: "Incubateur",
            date_achat: new Date("2020-06-10"),
            maintenances: [
              { date: new Date("2024-02-01"), description: "Contrôle sécurité" }
            ]
          }
        ]
      }
    ]
  },

  {
    _id: 3,
    nom: "Clinique du Parc",
    adresse: "45 rue Nationale, Roubaix",
    telephone: "0320706060",
    type: "prive",
    categorie: "clinique",
    services: [
      {
        id_service: 4,
        nom: "Imagerie médicale",
        machines: [
          {
            type: "IRM",
            date_achat: new Date("2019-09-01"),
            maintenances: [
              { date: new Date("2024-02-20"), description: "Maintenance IRM" }
            ]
          }
        ]
      }
    ]
  }
]);


db.personnels.insertMany([
  { _id: 1, nom: "Martin", prenom: "Jean", specialite: "Urgentiste", categorie: "soignant" },
  { _id: 2, nom: "Dupont", prenom: "Claire", specialite: "Cardiologue", categorie: "soignant" },
  { _id: 3, nom: "Bernard", prenom: "Luc", specialite: "Radiologue", categorie: "soignant" },
  { _id: 5, nom: "Morel", prenom: "Sophie", specialite: "Pédiatre", categorie: "soignant" },
  { _id: 15, nom: "Perrin", prenom: "Thomas", specialite: "Médecin généraliste", categorie: "soignant" }
]);



db.medicaments.insertMany([
  { _id: 1, nom: "Doliprane", laboratoire: "Sanofi" },
  { _id: 2, nom: "Amoxicilline", laboratoire: "GSK" },
  { _id: 3, nom: "Ventoline", laboratoire: "GSK" },
  { _id: 4, nom: "Aspirine", laboratoire: "Bayer" }
]);


db.patients.insertOne({
  _id: 1,
  nom: "Durand",
  prenom: "Paul",
  date_naissance: new Date("1980-04-12"),
  adresse: "Lille",
  telephone: "0611223344",
  mail: "paul.durand@mail.fr",

  pathologies: [
    { nom: "Hypertension" }
  ],

  constantes: [
    { type: "temperature", valeur: 37.2, date: new Date("2024-01-10T08:00:00") },
    { type: "tension", valeur: 120, date: new Date("2024-01-10T08:05:00") }
  ],

  parcours_soins: [
    {
      date_entree: new Date("2024-01-10"),
      date_sortie: new Date("2024-01-15"),

      rendez_vous: [
        {
          date: new Date("2024-01-10T09:00:00"),
          motif: "Douleur thoracique",
          personnel: { id: 2, nom: "Dupont" },
          diagnostic: "Suspicion d’infarctus",
          traitements: [
            {
              description: "Traitement douleur",
              medicaments: [
                { nom: "Doliprane", posologie: "1g x3/jour" },
                { nom: "Aspirine", posologie: "500mg x2/jour" }
              ]
            }
          ]
        }
      ],

      actes_medicaux: [
        {
          description: "ECG",
          date_prevu: new Date("2024-01-10T10:00:00"),
          service: "Cardiologie"
        }
      ]
    }
  ]
});

db.patients.insertOne({
  _id: 2,
  nom: "Leroy",
  prenom: "Marie",
  date_naissance: new Date("1992-07-23"),
  adresse: "Roubaix",
  telephone: "0622334455",
  mail: "marie.leroy@mail.fr",

  parcours_soins: [
    {
      date_entree: new Date("2024-02-05"),
      date_sortie: new Date("2024-02-08"),
      rendez_vous: [
        {
          date: new Date("2024-02-05T14:00:00"),
          motif: "Consultation générale",
          personnel: { id: 15, nom: "Perrin" },
          diagnostic: "Bronchite aiguë",
          traitements: [
            {
              description: "Antibiothérapie",
              medicaments: [
                { nom: "Amoxicilline", posologie: "500mg x3/jour" }
              ]
            }
          ]
        }
      ]
    }
  ]
});

db.patients.insertOne({
  _id: 3,
  nom: "Moreau",
  prenom: "Julien",
  date_naissance: new Date("1975-01-05"),
  adresse: "Tourcoing",
  telephone: "0633445566",
  mail: "julien.moreau@mail.fr",
  pathologies: [
    { nom: "Arthrose" }
  ]
});

db.patients.insertOne({
  _id: 4,
  nom: "Favier",
  prenom: "Lucie",
  date_naissance: new Date("2001-10-14"),
  adresse: "Amiens",
  telephone: "0644556677",
  mail: "lucie.favier@mail.fr"
});


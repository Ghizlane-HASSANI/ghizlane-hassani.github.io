insert into etablissements (nom, adresse, telephone, type_etablissement, categorie) values
('CHU de Lille', '2 avenue Oscar Lambret, Lille', '0320445000', 'public', 'hopital'),
('CH d’Amiens', '1 rue du Professeur Christian Cabrol, Amiens', '0322088000', 'public', 'hopital'),
('CH de Valenciennes', 'Avenue Désandrouin, Valenciennes', '0327340000', 'public', 'hopital'),
('Clinique du Parc', '45 rue Nationale, Roubaix', '0320706060', 'prive', 'clinique'),
('Clinique Sainte-Isabelle', 'Boulevard Vauban, Lille', '0320171717', 'prive', 'clinique'),
('Centre de santé Lens', '12 rue de Paris, Lens', '0321791234', 'public', 'centre de sante'),
('CH de Dunkerque', '130 avenue Louis Herbeaux, Dunkerque', '0328285000', 'public', 'hopital'),
('CH d’Arras', '1 rue Émile Legrelle, Arras', '0321212121', 'public', 'hopital'),
('Clinique de Flandre', '10 rue des Fusillés, Hazebrouck', '0328424242', 'prive', 'clinique'),
('Centre médical Tourcoing', '5 rue de Gand, Tourcoing', '0320558899', 'public', 'centre de sante');

insert into services (nom, etablissement_id) values
('Urgences', 1),
('Cardiologie', 1),
('Radiologie', 1),
('Pédiatrie', 2),
('Médecine générale', 2),
('Chirurgie', 3),
('Orthopédie', 3),
('Imagerie médicale', 4),
('Gynécologie', 5),
('Soins infirmiers', 6),
('Réanimation', 7),
('Neurologie', 8),
('Oncologie', 8),
('Dermatologie', 9),
('Consultations externes', 10);


insert into personnels (nom, prenom, specialite, categorie) values
('Martin', 'Jean', 'Urgentiste', 'soignant'),
('Dupont', 'Claire', 'Cardiologue', 'soignant'),
('Bernard', 'Luc', 'Radiologue', 'soignant'),
('Petit', 'Anne', 'Infirmière', 'soignant'),
('Morel', 'Sophie', 'Pédiatre', 'soignant'),
('Lefebvre', 'Paul', 'Chirurgien', 'soignant'),
('Roux', 'Julie', 'Orthopédiste', 'soignant'),
('Fontaine', 'Marc', NULL, 'administratif'),
('Gauthier', 'Isabelle', NULL, 'administratif'),
('Lambert', 'Eric', NULL, 'technique'),
('Girard', 'Nicolas', NULL, 'entretien'),
('Lemoine', 'Sarah', 'Infirmière', 'soignant'),
('Fournier', 'Alain', 'Neurologue', 'soignant'),
('Blanc', 'Camille', 'Oncologue', 'soignant'),
('Perrin', 'Thomas', 'Médecin généraliste', 'soignant');


insert into services_personnels values
(1,1),(1,4),(1,8),(1,10),(1,15),
(2,2),(2,4),(2,8),(2,10)
(3,3),(3,8),(3,10),
(4,5),(4,9),(4,12),
(5,9),(5,12),
(6,6),(6,4),(6,11),
(7,6),(7,7),(7,11),
(10,12),
(11,1),
(12,13),
(13,14),
(15,15),
(8,3),
(9,5),
(14,15);


insert into patients (nom, prenom, date_naissance, adresse, telephone, mail) values
('Durand','Paul','1980-04-12','Lille','0611223344','paul.durand@mail.fr'),
('Leroy','Marie','1992-07-23','Roubaix','0622334455','marie.leroy@mail.fr'),
('Moreau','Julien','1975-01-05','Tourcoing','0633445566','julien.moreau@mail.fr'),
('Favier','Lucie','2001-10-14','Amiens','0644556677','lucie.favier@mail.fr'),
('Gomez','Carlos','1988-06-30','Valenciennes','0655667788','carlos.gomez@mail.fr'),
('Petit','Emma','2015-03-11','Lens','0666778899','emma.petit@mail.fr'),
('Renard','Michel','1963-12-01','Arras','0677889900','michel.renard@mail.fr'),
('Lopez','Ana','1990-08-09','Dunkerque','0688990011','ana.lopez@mail.fr'),
('Colin','Thomas','1985-02-17','Hazebrouck','0699001122','thomas.colin@mail.fr'),
('Noel','Sarah','1998-11-22','Lille','0600112233','sarah.noel@mail.fr'),
('Marchand','Eric','1970-09-05','Tourcoing','0612345678','eric.marchand@mail.fr'),
('Benoit','Julie','2004-05-19','Roubaix','0623456789','julie.benoit@mail.fr');

insert into parcours_soins (date_entree, date_sortie, patient_id) values
('2024-01-10','2024-01-15',1),
('2024-02-05','2024-02-08',2),
('2024-03-01','2024-03-10',3),
('2024-03-12','2024-03-14',4),
('2024-04-01',NULL,5),
('2024-04-10','2024-04-12',6),
('2024-05-02','2024-05-09',7),
('2024-05-15','2024-05-20',8),
('2024-06-01','2024-06-03',9),
('2024-06-10',NULL,10),
('2024-07-01','2024-07-04',11),
('2024-07-10','2024-07-12',12);


insert into rendez_vous (date_rendez_vous, motif, patient_id, personnel_id, parcours_id) values
('2024-01-10 09:00','Douleur thoracique',1,2,1),
('2024-01-11 10:00','Radio thorax',1,3,1),
('2024-02-05 14:00','Consultation générale',2,15,2),
('2024-03-01 11:00','Chirurgie programmée',3,6,3),
('2024-03-13 09:30','Consultation pédiatrie',4,5,4),
('2024-04-01 08:00','Urgences',5,1,5),
('2024-04-10 15:00','Suivi',6,15,6),
('2024-05-02 10:30','IRM',7,3,7),
('2024-05-16 13:00','Consultation',8,15,8),
('2024-06-01 09:00','Dermatologie',9,15,9),
('2024-06-10 11:00','Contrôle',10,2,10),
('2024-07-01 10:00','Neurologie',11,13,11),
('2024-07-10 09:00','Oncologie',12,14,12),
('2024-07-11 14:00','Suivi',12,14,12),
('2024-07-12 16:00','Sortie',12,8,12);


insert into diagnostics (description, rendez_vous_id) values
('Suspicion d’infarctus', 1),
('Bronchite aiguë', 3),
('Fracture du fémur', 4),
('Otite moyenne', 5),
('Crise d’asthme', 6),
('Contrôle post-opératoire', 7),
('Hernie discale', 8),
('Hypertension artérielle', 9),
('Eczéma chronique', 10),
('Trouble du rythme cardiaque', 11),
('AVC ischémique', 12),
('Cancer du sein', 13);


insert into medicaments (nom, laboratoire) values
('Doliprane', 'Sanofi'),
('Amoxicilline', 'GSK'),
('Ventoline', 'GSK'),
('Aspirine', 'Bayer'),
('Ibuprofène', 'Pfizer'),
('Paracétamol', 'Upsa'),
('Morphine', 'Mylan'),
('Metformine', 'Merck'),
('Atorvastatine', 'Pfizer'),
('Lévothyrox', 'Sanofi'),
('Oméprazole', 'AstraZeneca'),
('Tamoxifène', 'Roche');


insert into traitements (description) values
('Traitement douleur'),
('Antibiothérapie'),
('Traitement asthme'),
('Antalgique post-op'),
('Anti-inflammatoire'),
('Traitement hypertension'),
('Antalgie forte'),
('Protection gastrique'),
('Traitement diabète'),
('Traitement thyroïde'),
('Traitement AVC'),
('Traitement oncologique');


insert into traitements_medicaments (traitement_id, medicament_id, posologie) values
(1,1,'1g x3/jour'),
(1,4,'500mg x2/jour'),
(2,2,'500mg x3/jour'),
(3,3,'2 inhalations/jour'),
(4,5,'400mg x2/jour'),
(5,6,'400mg x3/jour'),
(6,9,'1 comprimé/jour'),
(7,7,'10mg si douleur'),
(8,11,'20mg le matin'),
(9,8,'1 comprimé matin et soir'),
(10,10,'50µg/jour'),
(11,4,'75mg/jour'),
(11,9,'1 comprimé/jour'),
(12,12,'1 comprimé/jour'),
(12,11,'20mg/jour');


insert into patients_traitements values
(1,1),
(2,2),
(3,4),
(4,2),
(5,3),
(6,1),
(7,8),
(8,6),
(9,5),
(10,9),
(11,11),
(12,12);


insert into pathologies (nom, description) values
('Hypertension', 'Pression artérielle élevée'),
('Diabète', 'Dérèglement du taux de glucose'),
('Asthme', 'Maladie respiratoire chronique'),
('Cancer', 'Prolifération cellulaire anormale'),
('Arthrose', 'Dégénérescence articulaire'),
('AVC', 'Accident vasculaire cérébral'),
('Bronchite', 'Inflammation des bronches'),
('Eczéma', 'Affection cutanée'),
('Fracture', 'Rupture osseuse'),
('Hernie discale', 'Atteinte du disque intervertébral');


insert into traitements_pathologies values
(1,1),
(2,7),
(3,3),
(4,5),
(5,5),
(6,1),
(7,5),
(8,8),
(9,2),
(10,10),
(11,6),
(12,4);

insert into patients_pathologies values
(1,1),
(2,7),
(3,9),
(4,7),
(5,3),
(6,3),
(7,5),
(8,1),
(9,8),
(10,2),
(11,6),
(12,4),
(12,1),
(3,5);


insert into constantes (valeur, type_constante, date_enregistrement, patient_id) values
(37.2,'temperature (°C)','2024-01-10 08:00',1),
(120,'tension (mmHg)','2024-01-10 08:05',1),
(38.1,'temperature (°C)','2024-02-05 13:50',2),
(135,'tension (mmHg)','2024-02-05 13:55',2),
(36.8,'temperature (°C)','2024-03-01 10:30',3),
(90,'frequence cardiaque (bpm)','2024-03-01 10:35',3),
(37.5,'temperature (°C)','2024-04-01 07:45',5),
(110,'frequence cardiaque (bpm)','2024-04-01 07:50',5),
(36.9,'temperature (°C)','2024-05-02 10:15',7),
(140,'tension (mmHg)','2024-05-02 10:20',7),
(37.0,'temperature (°C)','2024-06-01 08:45',9),
(80,'frequence cardiaque (bpm)','2024-06-01 08:50',9),
(36.7,'temperature (°C)','2024-07-01 09:45',11),
(85,'frequence respiratoire (rpm)','2024-07-01 09:50',11),
(37.8,'temperature (°C)','2024-07-10 08:30',12),
(145,'tension (mmHg)','2024-07-10 08:35',12),
(37.1,'temperature (°C)','2024-07-11 08:00',12),
(82,'frequence cardiaque (bpm)','2024-07-11 08:05',12),
(36.9,'temperature (°C)','2024-07-12 07:50',12),
(78,'frequence cardiaque (bpm)','2024-07-12 07:55',12);


insert into actes_medicaux (description, date_prevu, service_id, parcours_id) values
('ECG','2024-01-10 10:00',2,1),
('Radiographie thoracique','2024-01-11 11:00',3,1),
('Consultation générale','2024-02-05 14:00',5,2),
('Intervention chirurgicale','2024-03-01 12:00',6,3),
('Consultation pédiatrique','2024-03-13 10:00',4,4),
('Traitement urgence','2024-04-01 09:00',1,5),
('IRM lombaire','2024-05-02 11:00',3,7),
('Consultation dermatologique','2024-06-01 10:00',14,9),
('Consultation neurologique','2024-07-01 11:00',12,11),
('Chimiothérapie','2024-07-10 10:00',13,12),
('Suivi oncologique','2024-07-11 15:00',13,12),
('Bilan de sortie','2024-07-12 16:00',15,12);


insert into actes_personnels values
(1,2),
(2,3),
(3,15),
(4,6),
(5,5),
(6,1),
(7,3),
(8,15),
(9,13),
(10,14),
(11,14),
(12,8),
(4,4),
(6,12),
(7,10);


insert into machines (type_machine, date_achat, date_mise_service, date_derniere_maintenance, service_id) values
('Scanner','2020-01-15','2020-03-01','2024-01-10',3),
('IRM','2019-06-10','2019-09-01','2024-02-20',3),
('Respirateur','2021-02-12','2021-03-01','2024-03-15',1),
('Moniteur cardiaque','2022-05-01','2022-06-01','2024-04-05',2),
('Table de radiologie','2018-09-20','2018-10-01','2024-01-30',3),
('Pompe à perfusion','2021-11-11','2021-12-01','2024-05-12',10),
('Échographe','2020-08-08','2020-09-01','2024-02-28',9),
('Lit médicalisé','2023-01-01','2023-01-15','2024-06-01',11),
('Défibrillateur','2022-03-10','2022-04-01','2024-03-20',1),
('Appareil ECG','2021-04-18','2021-05-01','2024-04-18',2),
('Scanner','2009-05-12','2012-01-28','2022-09-09',3),
('IRM','2002-02-02','2003-03-03','2023-03-23',3);


insert into maintenances (date_maintenance, description, machine_id) values
('2024-01-10','Maintenance annuelle scanner',1),
('2024-02-20','Contrôle IRM',2),
('2024-03-15','Révision respirateur',3),
('2024-04-05','Calibration moniteur',4),
('2024-01-30','Réglage table radio',5),
('2024-05-12','Nettoyage pompe perfusion',6),
('2024-02-28','Mise à jour logiciel échographe',7),
('2024-06-01','Vérification lit médicalisé',8),
('2024-03-20','Test défibrillateur',9),
('2024-04-18','Contrôle ECG',10),
('2024-05-01','Maintenance préventive',1),
('2024-06-10','Révision complète',2),
('2024-07-01','Changement pièce',3),
('2024-07-05','Mise à jour firmware',4),
('2024-07-10','Contrôle sécurité',9),
('2023-03-23','Contrôle sécurité',12),
('2022-09-09','Révision complète',11);

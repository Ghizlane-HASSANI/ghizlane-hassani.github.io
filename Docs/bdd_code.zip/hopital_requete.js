// Lister les patientavec nom, prénoms et date de naissance
db.patients.find(
  {},
  { nom: 1, prenom: 1, date_naissance: 1 }
);


// Patients avec un parcours de soins
db.patients.find({
  parcours_soins: { $exists: true, $ne: [] }
});

// Rendez-vous de Durand Paul 
db.patients.find(
  { nom: "Durand", prenom: "Paul" },
  { "parcours_soins.rendez_vous": 1 }
);

// Etablissements publics
db.etablissements.find(
  { type: "public" },
  { nom: 1, categorie: 1 }
);


// Patient à Lille
db.patients.find(
  { adresse: "Amiens" },
  { nom: 1, prenom: 1, _id: 0 }
);
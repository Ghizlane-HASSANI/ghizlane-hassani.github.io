-- Question 4.a
select 
    p.id_patient,
    am.id_acte_medical,
    am.description,
    am.date_prevu
from patients p
join parcours_soins ps
    ON ps.patient_id = p.id_patient
join actes_medicaux am
    ON am.parcours_id = ps.id_parcours
order by p.id_patient, am.date_prevu;

-- Question 4.b
select *
from machines
where date_achat <= DATE_SUB(CURDATE(), INTERVAL 10 YEAR)
  and date_derniere_maintenance <= DATE_SUB(CURDATE(), INTERVAL 1 YEAR);

-- Question 4.c
select 
    e.id_etablissement,
    e.nom,
    s.id_service,
    s.nom,
    COUNT(DISTINCT p.id_patient) AS nombre_patients
from etablissements e
join services s
    ON s.etablissement_id = e.id_etablissement
join actes_medicaux am
    ON am.service_id = s.id_service
join parcours_soins ps
    ON ps.id_parcours = am.parcours_id
join patients p
    ON p.id_patient = ps.patient_id
group by e.id_etablissement, s.id_service
order by nombre_patients DESC
LIMIT 1;

-- Question 4.d
-- Version 1
select 
    e.id_etablissement,
    e.nom AS etablissement,
    p.id_personnel,
    p.nom,
    p.prenom
from etablissements e
join services s 
    ON s.etablissement_id = e.id_etablissement
join services_personnels sp 
    ON sp.service_id = s.id_service
join personnels p 
    ON p.id_personnel = sp.personnel_id
group by 
    e.id_etablissement,
    p.id_personnel
HAVING COUNT(DISTINCT s.id_service) = (
    select COUNT(*)
    from services s2
    where s2.etablissement_id = e.id_etablissement
)
order by e.nom, p.nom;

-- Version 2
select
    e.id_etablissement,
    e.nom AS etablissement,
    p.id_personnel,
    p.nom,
    p.prenom
from etablissements e
join personnels p
where NOT EXISTS (
    select 1
    from services s
    where s.etablissement_id = e.id_etablissement
      and NOT EXISTS (
          select 1
          from services_personnels sp
          where sp.service_id = s.id_service
            and sp.personnel_id = p.id_personnel
      )
)
order by e.nom, p.nom;


-- Question 5.1 : Quelles sont les 4 machines qui ont subi le plus de maintenances ?

select 
    m.id_machine, 
    m.type_machine, 
    COUNT(ma.id_maintenance) AS nb_maintenances
from machines m, maintenances ma
where m.id_machine = ma.id_machine
group by m.id_machine, m.type_machine
order by nb_maintenances DESC;


-- Question 5.2 : Quels services n’ont réalisé aucun acte médical ?

select 
    s.id_service,
    s.nom
from services s
where NOT EXISTS (
    select *
    from actes_medicaux am
    where am.service_id = s.id_service
);


-- Question 5.3 : Quels patients sont entrés à l’hôpital après le 1er juin 2024 ?

select 
    p.id_patient, 
    p.nom, 
    p.prenom
from patients p, parcours_soins ps
where p.id_patient = ps.patient_id
AND ps.date_entree > '2024-01-01';
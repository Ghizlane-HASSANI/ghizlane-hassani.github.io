from flask import Flask
from routes import auth_routes, patients, rdv, consultations, prescriptions, allergies, antecedents, lettres, analyses, documents

app = Flask(__name__)

app.register_blueprint(auth_routes.bp)
app.register_blueprint(patients.bp)
app.register_blueprint(rdv.bp)
app.register_blueprint(consultations.bp)
app.register_blueprint(prescriptions.bp)
app.register_blueprint(allergies.bp)
app.register_blueprint(antecedents.bp)
app.register_blueprint(lettres.bp)
app.register_blueprint(analyses.bp)
app.register_blueprint(documents.bp)

if __name__ == "__main__":
    app.run(debug=True)

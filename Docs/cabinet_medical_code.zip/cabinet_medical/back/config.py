import os

DB_CONFIG = {
    "host":     os.environ.get("DB_HOST", "db"),
    "user":     os.environ.get("DB_USER", "root"),
    "password": os.environ.get("DB_PASSWORD", ""),
    "database": os.environ.get("DB_NAME", "cabinet_medical")
}

SECRET_KEY = os.environ.get("SECRET_KEY", "cabinet_medical_secret_key")
JWT_EXPIRATION_HOURS = int(os.environ.get("JWT_EXPIRATION_HOURS", 8))
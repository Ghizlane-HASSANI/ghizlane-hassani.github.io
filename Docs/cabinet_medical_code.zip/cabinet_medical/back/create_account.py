# create_account.py
# Usage :
#   python create_account.py medecin   <login> <nom> <prenom> <email> <mot_de_passe> <specialite> <numero_rpps>
#   python create_account.py secretaire <login> <nom> <prenom> <email> <mot_de_passe> <numero_poste> <service>

import sys
import mysql.connector
from werkzeug.security import generate_password_hash
from config import DB_CONFIG

USAGE = """
Usage :
  python create_account.py medecin    <login> <nom> <prenom> <email> <mot_de_passe> <specialite> <numero_rpps>
  python create_account.py secretaire <login> <nom> <prenom> <email> <mot_de_passe> <numero_poste> <service>
"""

def create_utilisateur(cur, login, nom, prenom, email, mot_de_passe):
    hashed = generate_password_hash(mot_de_passe)
    cur.execute(
        "INSERT INTO Utilisateur (login, nom, prenom, email, mot_de_passe) VALUES (%s,%s,%s,%s,%s)",
        (login, nom, prenom, email, hashed)
    )
    return cur.lastrowid

def create_medecin(args):
    if len(args) != 8:
        print("Médecin : 8 arguments attendus.")
        print(USAGE); sys.exit(1)

    _, login, nom, prenom, email, mot_de_passe, specialite, numero_rpps = args

    db = mysql.connector.connect(**DB_CONFIG)
    cur = db.cursor()

    id_utilisateur = create_utilisateur(cur, login, nom, prenom, email, mot_de_passe)
    cur.execute(
        "INSERT INTO Medecin (specialite, numero_rpps, id_utilisateur) VALUES (%s,%s,%s)",
        (specialite, numero_rpps, id_utilisateur)
    )

    db.commit(); cur.close(); db.close()
    print(f"Médecin '{prenom} {nom}' créé avec succès.")

def create_secretaire(args):
    if len(args) != 8:
        print("Secrétaire : 8 arguments attendus.")
        print(USAGE); sys.exit(1)

    _, login, nom, prenom, email, mot_de_passe, numero_poste, service = args

    db = mysql.connector.connect(**DB_CONFIG)
    cur = db.cursor()

    id_utilisateur = create_utilisateur(cur, login, nom, prenom, email, mot_de_passe)
    cur.execute(
        "INSERT INTO Secretaire (numero_poste, service, id_utilisateur) VALUES (%s,%s,%s)",
        (numero_poste, service, id_utilisateur)
    )

    db.commit(); cur.close(); db.close()
    print(f"Secrétaire '{prenom} {nom}' créée avec succès.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(USAGE); sys.exit(1)

    role = sys.argv[1].lower()

    try:
        if role == "medecin":
            create_medecin(sys.argv[1:])
        elif role == "secretaire":
            create_secretaire(sys.argv[1:])
        else:
            print(f"Rôle inconnu : '{role}'. Choisir 'medecin' ou 'secretaire'.")
            print(USAGE); sys.exit(1)

    except mysql.connector.IntegrityError as e:
        print(f"Erreur : login, email ou numéro RPPS déjà utilisé. ({e})")
        sys.exit(1)
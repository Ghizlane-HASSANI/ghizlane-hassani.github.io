import mysql.connector
from datetime import timedelta
from config import DB_CONFIG

def get_db():
    return mysql.connector.connect(**DB_CONFIG)

def to_dict(row):
    if row is None:
        return None
    result = {}
    for k, v in row.items():
        if isinstance(v, timedelta):
            # Convertit timedelta en "HH:MM:SS"
            total = int(v.total_seconds())
            result[k] = f"{total // 3600:02}:{(total % 3600) // 60:02}:{total % 60:02}"
        elif hasattr(v, "isoformat"):
            result[k] = v.isoformat()
        else:
            result[k] = v
    return result
"""
Script de generation de documents PDF de demonstration.
Usage : docker-compose exec back python generate_docs.py
"""

import os, uuid
from fpdf import FPDF
from db import get_db

UPLOAD_DIR = os.environ.get("UPLOAD_DIR", "/app/uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)


# ── Helpers PDF ───────────────────────────────────────────────────────────────

def new_pdf():
    pdf = FPDF()
    pdf.set_margins(20, 20, 20)
    pdf.add_page()
    return pdf

def header_cabinet(pdf, titre):
    pdf.set_font("Helvetica", "B", 16)
    pdf.set_text_color(26, 74, 58)
    pdf.cell(0, 8, "Cabinet Medical de Ville", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(0, 5, "12 avenue de la Republique - 75011 Paris  |  Tel : 01 23 45 67 89",
             new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)
    pdf.set_draw_color(200, 169, 110)
    pdf.set_line_width(0.8)
    pdf.line(20, pdf.get_y(), 190, pdf.get_y())
    pdf.ln(5)
    pdf.set_font("Helvetica", "B", 13)
    pdf.set_text_color(26, 74, 58)
    pdf.cell(0, 8, titre, new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)

def section(pdf, label):
    pdf.ln(4)
    pdf.set_fill_color(240, 230, 208)
    pdf.set_font("Helvetica", "B", 10)
    pdf.set_text_color(26, 74, 58)
    pdf.cell(0, 7, f"  {label}", new_x="LMARGIN", new_y="NEXT", fill=True)
    pdf.set_text_color(30, 30, 30)
    pdf.ln(2)

def ligne(pdf, label, valeur):
    pdf.set_font("Helvetica", "B", 9)
    pdf.set_text_color(80, 80, 80)
    pdf.cell(55, 6, label + " :", new_x="RIGHT", new_y="TOP")
    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(30, 30, 30)
    pdf.multi_cell(115, 6, str(valeur))

def texte(pdf, contenu):
    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(40, 40, 40)
    pdf.multi_cell(0, 5.5, contenu)

def table_header(pdf, cols):
    pdf.set_font("Helvetica", "B", 9)
    pdf.set_fill_color(230, 240, 255)
    for label, w in cols:
        pdf.cell(w, 6, label, border=1, fill=True)
    pdf.ln()

def table_row(pdf, vals_widths):
    pdf.set_font("Helvetica", "", 9)
    for val, w in vals_widths:
        pdf.cell(w, 6, val, border=1)
    pdf.ln()

def footer_medecin(pdf, medecin, date):
    pdf.ln(10)
    pdf.set_draw_color(200, 169, 110)
    pdf.set_line_width(0.4)
    pdf.line(20, pdf.get_y(), 190, pdf.get_y())
    pdf.ln(4)
    pdf.set_font("Helvetica", "I", 9)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(0, 5, f"Document etabli le {date} par {medecin}", new_x="LMARGIN", new_y="NEXT")

def save_pdf(pdf, nom_original, type_doc, description, id_patient, db, cur):
    nom_stockage = f"{uuid.uuid4().hex}.pdf"
    path = os.path.join(UPLOAD_DIR, nom_stockage)
    pdf.output(path)
    cur.execute(
        """INSERT INTO Document (nom_original, nom_stockage, type_document, description, mime_type, id_patient)
           VALUES (%s, %s, %s, %s, %s, %s)""",
        (nom_original, nom_stockage, type_doc, description, "application/pdf", id_patient)
    )
    db.commit()
    print(f"  -> {nom_original}")


# ── Generation des documents ──────────────────────────────────────────────────

def gen_docs():
    db = get_db()
    cur = db.cursor(dictionary=True)

    cur.execute("""
        SELECT p.id_patient, u.nom, u.prenom, p.date_de_naissance, p.sexe, p.numero_secu
        FROM Patient p JOIN Utilisateur u ON p.id_utilisateur = u.id_utilisateur
        ORDER BY p.id_patient
    """)
    patients = cur.fetchall()

    for p in patients:
        pid    = p["id_patient"]
        nom    = p["nom"]
        prenom = p["prenom"]
        ddn    = str(p["date_de_naissance"])
        secu   = p["numero_secu"]
        civ    = "M." if p["sexe"] == "M" else "Mme"
        print(f"\nPatient {pid} - {civ} {prenom} {nom}")

        # ── Patient 1 : Claire Durand ─────────────────────────────────────

        if pid == 1:
            # Hemogramme
            pdf = new_pdf()
            header_cabinet(pdf, "Resultats d'Analyse de Biologie Medicale")
            section(pdf, "Identite du patient")
            ligne(pdf, "Patient",    f"{civ} {prenom} {nom}")
            ligne(pdf, "Nee le",     ddn)
            ligne(pdf, "N° Secu",    secu)
            section(pdf, "Hemogramme complet - 09/01/2025")
            ligne(pdf, "Laboratoire", "Laboratoire BioParis - 8 rue de Rivoli, 75001 Paris")
            ligne(pdf, "Prescripteur", "Dr. Sophie Martin - Medecine generale")
            pdf.ln(2)
            cols = [("Parametre", 70), ("Resultat", 40), ("Unite", 30), ("Norme", 40)]
            table_header(pdf, cols)
            for r in [
                ("Globules rouges (GR)", "4,12", "T/L",   "4,20-5,40 (!)"),
                ("Hemoglobine",          "11,8",  "g/dL",  "12,0-16,0 (!)"),
                ("Hematocrite",          "36,2",  "%",     "37-47 (!)"),
                ("VGM",                  "88",    "fL",    "80-100"),
                ("Globules blancs",      "6,8",   "G/L",   "4,0-10,0"),
                ("Plaquettes",           "245",   "G/L",   "150-400"),
                ("Ferritine",            "8",     "ug/L",  "20-200 (!)"),
            ]:
                table_row(pdf, list(zip(r, [70, 40, 30, 40])))
            section(pdf, "Conclusion")
            texte(pdf, "Anemie ferriprive legere (hemoglobine a 11,8 g/dL, ferritine a 8 ug/L).\n"
                       "Recommandation : supplementation en fer oral (Tardyferon 80 mg/j x 3 mois).\n"
                       "Controle NFS + ferritine dans 4 semaines.")
            footer_medecin(pdf, "Dr. Sophie Martin", "09/01/2025")
            save_pdf(pdf, "Hemogramme_Durand_09012025.pdf", "analyse",
                     "Hemogramme complet - anemie ferriprive legere", pid, db, cur)

            # HbA1c
            pdf = new_pdf()
            header_cabinet(pdf, "Bilan Diabetologique - HbA1c et Glycemie")
            section(pdf, "Identite du patient")
            ligne(pdf, "Patient",    f"{civ} {prenom} {nom}")
            ligne(pdf, "Nee le",     ddn)
            ligne(pdf, "Diabete",    "Type 2 - diagnostique 03/2022 - traitement oral")
            section(pdf, "Resultats - 10/01/2025")
            cols = [("Parametre", 70), ("Resultat", 40), ("Unite", 30), ("Cible", 40)]
            table_header(pdf, cols)
            for r in [
                ("Glycemie a jeun",  "1,52", "g/L",   "< 1,26 (!)"),
                ("HbA1c",            "7,8",  "%",     "< 7,0 (!)"),
                ("Creatinine",       "68",   "umol/L","50-100"),
                ("DFG estime",       "88",   "mL/min","> 60"),
                ("Microalbuminurie", "Neg.", "",      "Negative"),
            ]:
                table_row(pdf, list(zip(r, [70, 40, 30, 40])))
            section(pdf, "Conclusion")
            texte(pdf, "Desequilibre glycemique (HbA1c a 7,8%). Adaptation du traitement necessaire.\n"
                       "Pas d'atteinte renale. Prochain bilan dans 3 mois.")
            footer_medecin(pdf, "Dr. Sophie Martin", "10/01/2025")
            save_pdf(pdf, "Bilan_Diabeto_Durand_10012025.pdf", "analyse",
                     "HbA1c et glycemie - desequilibre - adaptation traitement", pid, db, cur)

            # Compte-rendu consultation
            pdf = new_pdf()
            header_cabinet(pdf, "Compte Rendu de Consultation")
            section(pdf, "Identite du patient")
            ligne(pdf, "Patient", f"{civ} {prenom} {nom} - Nee le {ddn}")
            ligne(pdf, "N° Secu", secu)
            ligne(pdf, "Medecin", "Dr. Sophie Martin - Medecine generale")
            ligne(pdf, "Date",    "10 janvier 2025")
            section(pdf, "Motif de consultation")
            texte(pdf, "Suivi diabete de type 2 - renouvellement ordonnance et bilan trimestriel.")
            section(pdf, "Examen clinique")
            texte(pdf, "Poids : 68 kg. Taille : 165 cm. IMC : 25,0.\n"
                       "Tension arterielle : 130/80 mmHg. FC : 74 bpm.\n"
                       "Examen neuro membres inferieurs : sensibilite conservee.\n"
                       "Pas d'hypoglycemie rapportee.")
            section(pdf, "Bilan paraclinique")
            texte(pdf, "Glycemie a jeun : 1,52 g/L. HbA1c : 7,8% (objectif < 7%).\n"
                       "Anemie ferriprive legere associee (cf. bilan hemogramme).")
            section(pdf, "Conduite a tenir")
            texte(pdf, "- Metformine 1000 mg : 1 cp matin et soir.\n"
                       "- Ajout Glipizide 5 mg : 1 cp le matin.\n"
                       "- Tardyferon 80 mg/j pendant 3 mois.\n"
                       "- Controle glycemique mensuel a domicile.\n"
                       "- Prochain bilan HbA1c dans 3 mois.\n"
                       "- Consultation ophtalmologique annuelle recommandee.")
            footer_medecin(pdf, "Dr. Sophie Martin", "10/01/2025")
            save_pdf(pdf, "CR_Consultation_Durand_10012025.pdf", "compte_rendu",
                     "Compte-rendu consultation diabete - desequilibre glycemique", pid, db, cur)

        # ── Patient 2 : Jacques Moreau ────────────────────────────────────

        if pid == 2:
            # Bilan lipidique
            pdf = new_pdf()
            header_cabinet(pdf, "Bilan Lipidique et Cardiologique")
            section(pdf, "Identite du patient")
            ligne(pdf, "Patient", f"{civ} {prenom} {nom}")
            ligne(pdf, "Ne le",   ddn)
            ligne(pdf, "ATCD",    "IDM inferieur 2019, stent CD, allergie latex")
            section(pdf, "Resultats - 16/01/2025")
            cols = [("Parametre", 70), ("Resultat", 40), ("Unite", 30), ("Cible cardio", 40)]
            table_header(pdf, cols)
            for r in [
                ("Cholesterol total",  "2,18", "g/L",  "< 2,00 (!)"),
                ("LDL-cholesterol",    "1,42", "g/L",  "< 0,70 (!)"),
                ("HDL-cholesterol",    "0,38", "g/L",  "> 0,40 (!)"),
                ("Triglycerides",      "1,85", "g/L",  "< 1,50 (!)"),
                ("Troponine I",        "< 0,01","ug/L","< 0,04"),
                ("CRP ultra-sensible", "2,1",  "mg/L", "< 3,0"),
            ]:
                table_row(pdf, list(zip(r, [70, 40, 30, 40])))
            section(pdf, "Conclusion")
            texte(pdf, "Bilan lipidique insuffisamment controle chez patient coronarien.\n"
                       "LDL a 1,42 g/L (cible < 0,70). HDL bas. Renforcement statine discute.\n"
                       "Prochain bilan lipidique dans 6 semaines.")
            footer_medecin(pdf, "Dr. Paul Leroy", "16/01/2025")
            save_pdf(pdf, "Bilan_Lipidique_Moreau_16012025.pdf", "analyse",
                     "Bilan lipidique - LDL eleve chez coronarien", pid, db, cur)

            # Compte-rendu cardio
            pdf = new_pdf()
            header_cabinet(pdf, "Compte Rendu de Consultation Cardiologique")
            section(pdf, "Identite du patient")
            ligne(pdf, "Patient", f"{civ} {prenom} {nom} - Ne le {ddn}")
            ligne(pdf, "ATCD",    "IDM inferieur 2019, insuffisance mitrale legere, allergie latex")
            ligne(pdf, "Medecin", "Dr. Paul Leroy - Cardiologue")
            ligne(pdf, "Date",    "15 janvier 2025")
            section(pdf, "Motif de consultation")
            texte(pdf, "Suivi post-IDM et evaluation d'un souffle systolique.")
            section(pdf, "Examen clinique")
            texte(pdf, "PA : 138/82 mmHg. FC : 68 bpm reguliere. SpO2 : 97%.\n"
                       "Souffle systolique grade 2/6 en mitral. Pas de signe d'IC.\n"
                       "Pouls peripheriques presents et symetriques.")
            section(pdf, "Examens complementaires")
            texte(pdf, "ECG : rythme sinusal regulier 68/min, axe normal.\n"
                       "Pas de trouble de repolarisation ni de conduction.\n"
                       "LDL a 1,42 g/L (cible < 0,70 chez coronarien - insuffisant).")
            section(pdf, "Conduite a tenir")
            texte(pdf, "- Poursuite Bisoprolol 2,5 mg/j + Aspegic 75 mg/j.\n"
                       "- Renforcement statine : augmentation de dose.\n"
                       "- Echo-Doppler cardiaque dans 6 mois.\n"
                       "- Adressage cardiologie CHU Lyon pour bilan insuffisance mitrale.")
            footer_medecin(pdf, "Dr. Paul Leroy", "15/01/2025")
            save_pdf(pdf, "CR_Cardio_Moreau_15012025.pdf", "compte_rendu",
                     "Compte-rendu cardiologique - insuffisance mitrale legere", pid, db, cur)

        # ── Patient 3 : Emma Petit ────────────────────────────────────────

        if pid == 3:
            pdf = new_pdf()
            header_cabinet(pdf, "Resultats Bacteriologie et NFS")
            section(pdf, "Identite du patient")
            ligne(pdf, "Patient",  f"{civ} {prenom} {nom}")
            ligne(pdf, "Nee le",   ddn)
            ligne(pdf, "Allergie", "Penicilline - alternative prescrite")
            section(pdf, "TDR Streptocoque et NFS - 01/04/2025")
            cols = [("Examen", 80), ("Resultat", 50), ("Interpretation", 50)]
            table_header(pdf, cols)
            for r in [
                ("TDR Streptocoque A", "POSITIF",    "Angine bacterienne"),
                ("Leucocytes",         "14,2 G/L",   "Hyperleucocytose (!)"),
                ("Neutrophiles",       "82%",         "Predominance PNN"),
                ("CRP",                "48 mg/L",     "Syndrome inflammatoire (!)"),
                ("Hemoglobine",        "13,2 g/dL",  "Normale"),
            ]:
                table_row(pdf, list(zip(r, [80, 50, 50])))
            section(pdf, "Conclusion")
            texte(pdf, "Angine a Streptocoque A confirmee. Syndrome inflammatoire biologique.\n"
                       "Traitement : Azithromycine 500 mg/j x 3 jours (allergie penicilline).\n"
                       "Eviction scolaire jusqu'a apyrexie (24h apres debut antibiotherapie).")
            footer_medecin(pdf, "Dr. Linh Nguyen", "01/04/2025")
            save_pdf(pdf, "TDR_NFS_Petit_01042025.pdf", "analyse",
                     "TDR streptocoque positif - angine bacterienne", pid, db, cur)

        # ── Patient 5 : Isabelle Robert ───────────────────────────────────

        if pid == 5:
            pdf = new_pdf()
            header_cabinet(pdf, "Bilan Thyroidien - Suivi Hypothyroidie")
            section(pdf, "Identite du patient")
            ligne(pdf, "Patient", f"{civ} {prenom} {nom}")
            ligne(pdf, "Nee le",  ddn)
            ligne(pdf, "ATCD",    "Hypothyroidie Hashimoto 06/2018 - Levothyrox 75 ug/j")
            section(pdf, "Resultats - 18/02/2025")
            cols = [("Parametre", 70), ("Resultat", 40), ("Unite", 30), ("Norme", 40)]
            table_header(pdf, cols)
            for r in [
                ("TSH ultra-sensible", "1,82", "mUI/L",  "0,40-4,00"),
                ("T4 libre",           "14,3", "pmol/L", "12,0-22,0"),
                ("T3 libre",           "4,9",  "pmol/L", "3,5-6,5"),
                ("Anti-TPO",           "348",  "UI/mL",  "< 35 (!)"),
                ("Anti-Tg",            "215",  "UI/mL",  "< 115 (!)"),
            ]:
                table_row(pdf, list(zip(r, [70, 40, 30, 40])))
            section(pdf, "Conclusion")
            texte(pdf, "Euthyroidie sous traitement (TSH normale a 1,82 mUI/L).\n"
                       "Taux d'anticorps eleves confirment l'origine auto-immune (Hashimoto).\n"
                       "Poursuite Levothyrox 75 ug sans modification. Prochain controle dans 6 mois.")
            footer_medecin(pdf, "Dr. Paul Leroy", "18/02/2025")
            save_pdf(pdf, "Bilan_Thyroide_Robert_18022025.pdf", "analyse",
                     "Bilan thyroidien - euthyroidie sous Levothyrox", pid, db, cur)

        # ── Patient 6 : Antoine Simon ─────────────────────────────────────

        if pid == 6:
            # Imagerie radiographie
            pdf = new_pdf()
            header_cabinet(pdf, "Compte Rendu d'Imagerie - Radiographie des Genoux")
            section(pdf, "Identite du patient")
            ligne(pdf, "Patient", f"{civ} {prenom} {nom}")
            ligne(pdf, "Ne le",   ddn)
            ligne(pdf, "Motif",   "Douleurs bilaterales des genoux, raideur matinale")
            section(pdf, "Radiographie genoux face et profil en charge - 10/03/2025")
            ligne(pdf, "Radiologue", "Dr. Isabelle Fontaine - Service de Radiologie")
            ligne(pdf, "Technique",  "Incidences face et profil, en charge bilaterale")
            pdf.ln(3)
            texte(pdf,
                "GENOU DROIT :\n"
                "- Pincement modere de l'interligne femoro-tibial interne (grade 2 Kellgren-Lawrence).\n"
                "- Osteophytose condylienne interne debutante.\n"
                "- Epanchement articulaire discret.\n"
                "- Absence de lesion osseuse traumatique ou tumorale.\n\n"
                "GENOU GAUCHE :\n"
                "- Pincement discret de l'interligne femoro-tibial interne (grade 1).\n"
                "- Osteophytose legere sans epanchement.\n\n"
                "CONCLUSION : Gonarthrose bilaterale, predominante a droite (grade 2).\n"
                "Prise en charge : kinesitherapie de renforcement quadricipital, antalgiques palier 1,\n"
                "reduction ponderale conseillee (IMC 27,5). Suivi a 6 mois."
            )
            footer_medecin(pdf, "Dr. Isabelle Fontaine - Dr. Sophie Martin", "10/03/2025")
            save_pdf(pdf, "Radio_Genoux_Simon_10032025.pdf", "imagerie",
                     "Radiographie genoux - gonarthrose bilaterale grade 2 a droite", pid, db, cur)

            # Compte-rendu rhumato
            pdf = new_pdf()
            header_cabinet(pdf, "Compte Rendu de Consultation - Rhumatologie")
            section(pdf, "Identite du patient")
            ligne(pdf, "Patient", f"{civ} {prenom} {nom} - Ne le {ddn}")
            ligne(pdf, "IMC",     "27,5 - Surpoids leger")
            ligne(pdf, "Medecin", "Dr. Sophie Martin - Medecine generale")
            ligne(pdf, "Date",    "03 mars 2025")
            section(pdf, "Motif de consultation")
            texte(pdf, "Douleurs des deux genoux depuis 6 mois, aggravees a la montee des escaliers.\n"
                       "Raideur matinale de moins de 30 minutes.")
            section(pdf, "Examen clinique")
            texte(pdf, "Mobilite : flexion a 120 degres bilaterale, douleur en fin de course.\n"
                       "Epanchement discret du genou droit (choc rotulien positif).\n"
                       "Pas de laxite ligamentaire. Pas de blocage.")
            section(pdf, "Imagerie")
            texte(pdf, "Radiographie genoux (cf. compte-rendu radiologique) :\n"
                       "Gonarthrose bilaterale, predominante a droite (Kellgren-Lawrence grade 2).")
            section(pdf, "Conduite a tenir")
            texte(pdf, "- Paracetamol 500 mg x 3/j si douleur (eviter AINS - risque CV).\n"
                       "- Diclofenac gel topique sur les genoux 2 fois/j.\n"
                       "- Kinesitherapie : 10 seances renforcement quadricipital.\n"
                       "- Reduction ponderale conseillee (objectif : -3 a 5 kg).\n"
                       "- Adressage rhumatologie CHU Toulouse pour avis therapeutique.\n"
                       "- Reevaluation dans 3 mois.")
            footer_medecin(pdf, "Dr. Sophie Martin", "03/03/2025")
            save_pdf(pdf, "CR_Gonarthrose_Simon_03032025.pdf", "compte_rendu",
                     "Compte-rendu gonarthrose bilaterale - kinesitherapie + antalgiques", pid, db, cur)

    cur.close()
    db.close()
    print("\nGeneration terminee.")


if __name__ == "__main__":
    gen_docs()

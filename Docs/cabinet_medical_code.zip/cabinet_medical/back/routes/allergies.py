from flask import Blueprint, request, jsonify
from db import get_db, to_dict
from auth import login_required, role_required

bp = Blueprint("allergies", __name__)

@bp.route("/api/patients/<int:id_patient>/allergies", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def get_allergies(id_patient):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Allergie WHERE id_patient = %s", (id_patient,))
    allergies = [to_dict(r) for r in cur.fetchall()]
    cur.close(); db.close()
    return jsonify(allergies)


@bp.route("/api/allergies", methods=["POST"])
@login_required
@role_required("medecin")
def create_allergie():
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        "INSERT INTO Allergie (libelle, description, date_declaration, statut_allergie, id_patient) VALUES (%s,%s,%s,%s,%s)",
        (data["libelle"], data.get("description"), data.get("date_declaration"),
         data.get("statut_allergie", "active"), data["id_patient"])
    )
    db.commit()
    id_allergie = cur.lastrowid
    cur.close(); db.close()
    return jsonify({"message": "Allergie ajoutée", "id_allergie": id_allergie}), 201


@bp.route("/api/allergies/<int:id_allergie>", methods=["PUT"])
@login_required
@role_required("medecin")
def update_allergie(id_allergie):
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        "UPDATE Allergie SET libelle=%s, description=%s, statut_allergie=%s WHERE id_allergie=%s",
        (data["libelle"], data.get("description"), data.get("statut_allergie", "active"), id_allergie)
    )
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Allergie mise à jour"})


@bp.route("/api/allergies/<int:id_allergie>", methods=["DELETE"])
@login_required
@role_required("medecin")
def delete_allergie(id_allergie):
    db = get_db(); cur = db.cursor()
    cur.execute("DELETE FROM Allergie WHERE id_allergie = %s", (id_allergie,))
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Allergie supprimée"})
from flask import Blueprint, request, jsonify, g
from db import get_db, to_dict
from auth import login_required, role_required

bp = Blueprint("analyses", __name__)

@bp.route("/api/patients/<int:id_patient>/analyses", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def get_analyses(id_patient):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute(
        "SELECT a.*, u.nom AS medecin_nom, u.prenom AS medecin_prenom"
        " FROM Analyse a"
        " LEFT JOIN Medecin m ON a.id_medecin = m.id_medecin"
        " LEFT JOIN Utilisateur u ON m.id_utilisateur = u.id_utilisateur"
        " WHERE a.id_patient = %s"
        " ORDER BY a.date_analyse DESC",
        (id_patient,)
    )
    analyses = [to_dict(r) for r in cur.fetchall()]
    cur.close(); db.close()
    return jsonify(analyses)

@bp.route("/api/analyses", methods=["POST"])
@login_required
@role_required("medecin", "secretaire")
def create_analyse():
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        "INSERT INTO Analyse (type_analyse, laboratoire, date_analyse, resultat, commentaires, id_patient, id_medecin)"
        " VALUES (%s,%s,%s,%s,%s,%s,%s)",
        (
            data.get("type_analyse"),
            data.get("laboratoire"),
            data.get("date_analyse"),
            data.get("resultat"),
            data.get("commentaires"),
            data["id_patient"],
            g.user["role_id"] if g.user["role"] == "medecin" else None
        )
    )
    db.commit()
    id_analyse = cur.lastrowid
    cur.close(); db.close()
    return jsonify({"message": "Analyse ajoutée", "id_analyse": id_analyse}), 201

@bp.route("/api/analyses/<int:id_analyse>", methods=["PUT"])
@login_required
@role_required("medecin")
def update_analyse(id_analyse):
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        "UPDATE Analyse SET type_analyse=%s, laboratoire=%s, date_analyse=%s, resultat=%s, commentaires=%s"
        " WHERE id_analyse=%s",
        (
            data.get("type_analyse"),
            data.get("laboratoire"),
            data.get("date_analyse"),
            data.get("resultat"),
            data.get("commentaires"),
            id_analyse
        )
    )
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Analyse mise à jour"})

@bp.route("/api/analyses/<int:id_analyse>", methods=["DELETE"])
@login_required
@role_required("medecin")
def delete_analyse(id_analyse):
    db = get_db(); cur = db.cursor()
    cur.execute("DELETE FROM Analyse WHERE id_analyse = %s", (id_analyse,))
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Analyse supprimée"})

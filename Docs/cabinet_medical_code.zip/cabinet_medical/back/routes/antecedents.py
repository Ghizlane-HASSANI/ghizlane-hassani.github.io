from flask import Blueprint, request, jsonify
from db import get_db, to_dict
from auth import login_required, role_required

bp = Blueprint("antecedents", __name__)

@bp.route("/api/patients/<int:id_patient>/antecedents", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def get_antecedents(id_patient):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Antecedent WHERE id_patient = %s", (id_patient,))
    antecedents = [to_dict(r) for r in cur.fetchall()]
    cur.close(); db.close()
    return jsonify(antecedents)


@bp.route("/api/antecedents", methods=["POST"])
@login_required
@role_required("medecin")
def create_antecedent():
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        "INSERT INTO Antecedent (libelle, description, date_declaration, statut_antecedent, id_patient) VALUES (%s,%s,%s,%s,%s)",
        (data["libelle"], data.get("description"), data.get("date_declaration"),
         data.get("statut_antecedent", "actif"), data["id_patient"])
    )
    db.commit()
    id_antecedent = cur.lastrowid
    cur.close(); db.close()
    return jsonify({"message": "Antécédent ajouté", "id_antecedent": id_antecedent}), 201


@bp.route("/api/antecedents/<int:id_antecedent>", methods=["PUT"])
@login_required
@role_required("medecin")
def update_antecedent(id_antecedent):
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        "UPDATE Antecedent SET libelle=%s, description=%s, statut_antecedent=%s WHERE id_antecedent=%s",
        (data["libelle"], data.get("description"), data.get("statut_antecedent", "actif"), id_antecedent)
    )
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Antécédent mis à jour"})


@bp.route("/api/antecedents/<int:id_antecedent>", methods=["DELETE"])
@login_required
@role_required("medecin")
def delete_antecedent(id_antecedent):
    db = get_db(); cur = db.cursor()
    cur.execute("DELETE FROM Antecedent WHERE id_antecedent = %s", (id_antecedent,))
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Antécédent supprimé"})
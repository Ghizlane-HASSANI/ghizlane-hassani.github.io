import jwt
import datetime
from flask import Blueprint, request, jsonify, g
from werkzeug.security import check_password_hash
from db import get_db
from auth import login_required
from config import SECRET_KEY, JWT_EXPIRATION_HOURS

bp = Blueprint("auth", __name__)

@bp.route("/api/login", methods=["POST"])
def login():
    data = request.json
    login_val = data.get("login")
    password  = data.get("mot_de_passe")

    if not login_val or not password:
        return jsonify({"error": "Login et mot de passe requis"}), 400

    db = get_db()
    cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Utilisateur WHERE login = %s OR email = %s", (login_val, login_val))
    user = cur.fetchone()

    if not user or not check_password_hash(user["mot_de_passe"], password):
        cur.close(); db.close()
        return jsonify({"error": "Identifiants incorrects"}), 401

    uid = user["id_utilisateur"]

    role = None
    role_id = None
    for table, id_col in [("Medecin", "id_medecin"), ("Secretaire", "id_secretaire"), ("Patient", "id_patient")]:
        cur.execute(f"SELECT {id_col} FROM {table} WHERE id_utilisateur = %s", (uid,))
        row = cur.fetchone()
        if row:
            role    = table.lower()
            role_id = row[id_col]
            break

    cur.close(); db.close()

    token = jwt.encode({
        "user_id": uid,
        "role":    role,
        "role_id": role_id,
        "nom":     user["nom"],
        "prenom":  user["prenom"],
        "exp":     datetime.datetime.utcnow() + datetime.timedelta(hours=JWT_EXPIRATION_HOURS)
    }, SECRET_KEY, algorithm="HS256")

    return jsonify({"token": token, "role": role, "nom": user["nom"], "prenom": user["prenom"]})


@bp.route("/api/me", methods=["GET"])
@login_required
def me():
    return jsonify({
        "user_id": g.user["user_id"],
        "role":    g.user["role"],
        "role_id": g.user["role_id"],
        "nom":     g.user["nom"],
        "prenom":  g.user["prenom"]
    })
from flask import Blueprint, request, jsonify, g
from db import get_db, to_dict
from auth import login_required, role_required

bp = Blueprint("consultations", __name__)

@bp.route("/api/consultations", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def get_consultations():
    id_patient = request.args.get("id_patient")
    db = get_db(); cur = db.cursor(dictionary=True)
    if id_patient:
        cur.execute("SELECT * FROM Consultation WHERE id_patient = %s ORDER BY date_consultation DESC", (id_patient,))
    else:
        cur.execute("SELECT * FROM Consultation ORDER BY date_consultation DESC")
    consultations = [to_dict(r) for r in cur.fetchall()]
    cur.close(); db.close()
    return jsonify(consultations)


@bp.route("/api/consultations/<int:id_consultation>", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def get_consultation(id_consultation):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Consultation WHERE id_consultation = %s", (id_consultation,))
    c = cur.fetchone()
    cur.close(); db.close()
    if not c:
        return jsonify({"error": "Consultation introuvable"}), 404
    return jsonify(to_dict(c))


@bp.route("/api/consultations", methods=["POST"])
@login_required
@role_required("medecin")
def create_consultation():
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        """INSERT INTO Consultation
           (date_consultation, heure_debut, heure_fin, symptomes, observations, notes, diagnostic, id_rdv, id_patient, id_medecin)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (data["date_consultation"], data["heure_debut"], data.get("heure_fin"),
         data.get("symptomes"), data.get("observations"), data.get("notes"),
         data.get("diagnostic"), data.get("id_rdv"), data["id_patient"], g.user["role_id"])
    )
    if data.get("id_rdv"):
        cur.execute("UPDATE Rendez_vous SET statut='effectué' WHERE id_rdv=%s", (data["id_rdv"],))
    db.commit()
    id_consultation = cur.lastrowid
    cur.close(); db.close()
    return jsonify({"message": "Consultation créée", "id_consultation": id_consultation}), 201


@bp.route("/api/consultations/<int:id_consultation>", methods=["PUT"])
@login_required
@role_required("medecin")
def update_consultation(id_consultation):
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        """UPDATE Consultation
           SET symptomes=%s, observations=%s, notes=%s, diagnostic=%s, heure_fin=%s
           WHERE id_consultation=%s""",
        (data.get("symptomes"), data.get("observations"), data.get("notes"),
         data.get("diagnostic"), data.get("heure_fin"), id_consultation)
    )
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Consultation mise à jour"})


@bp.route("/api/consultations/<int:id_consultation>", methods=["DELETE"])
@login_required
@role_required("medecin")
def delete_consultation(id_consultation):
    db = get_db(); cur = db.cursor()
    cur.execute("DELETE FROM Consultation WHERE id_consultation = %s", (id_consultation,))
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Consultation supprimée"})
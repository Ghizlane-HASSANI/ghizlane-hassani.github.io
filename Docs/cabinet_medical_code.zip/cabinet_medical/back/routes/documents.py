from flask import Blueprint, request, jsonify, send_file
from db import get_db, to_dict
from auth import login_required, role_required
import os, uuid, io

bp = Blueprint("documents", __name__)

UPLOAD_DIR = os.environ.get("UPLOAD_DIR", "/app/uploads")
ALLOWED_EXTENSIONS = {"pdf", "png", "jpg", "jpeg"}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@bp.route("/api/patients/<int:id_patient>/documents", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def get_documents(id_patient):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Document WHERE id_patient = %s ORDER BY date_upload DESC", (id_patient,))
    docs = [to_dict(r) for r in cur.fetchall()]
    cur.close(); db.close()
    return jsonify(docs)


@bp.route("/api/patients/<int:id_patient>/documents", methods=["POST"])
@login_required
@role_required("medecin", "secretaire")
def upload_document(id_patient):
    if "fichier" not in request.files:
        return jsonify({"error": "Aucun fichier fourni"}), 400

    fichier = request.files["fichier"]
    if not fichier.filename or not allowed_file(fichier.filename):
        return jsonify({"error": "Type de fichier non autorisé (PDF, PNG, JPG uniquement)"}), 400

    ext = fichier.filename.rsplit(".", 1)[1].lower()
    nom_stockage = f"{uuid.uuid4().hex}.{ext}"
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    fichier.save(os.path.join(UPLOAD_DIR, nom_stockage))

    db = get_db(); cur = db.cursor()
    cur.execute(
        """INSERT INTO Document (nom_original, nom_stockage, type_document, description, mime_type, id_patient)
           VALUES (%s, %s, %s, %s, %s, %s)""",
        (fichier.filename, nom_stockage,
         request.form.get("type_document", "autre"),
         request.form.get("description", ""),
         fichier.content_type, id_patient)
    )
    db.commit()
    id_document = cur.lastrowid
    cur.close(); db.close()
    return jsonify({"message": "Document téléversé", "id_document": id_document}), 201


@bp.route("/api/documents/<int:id_document>/fichier", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def get_document_fichier(id_document):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Document WHERE id_document = %s", (id_document,))
    doc = cur.fetchone()
    cur.close(); db.close()
    if not doc:
        return jsonify({"error": "Document introuvable"}), 404

    path = os.path.join(UPLOAD_DIR, doc["nom_stockage"])
    if not os.path.exists(path):
        return jsonify({"error": "Fichier introuvable sur le serveur"}), 404

    return send_file(path, download_name=doc["nom_original"],
                     as_attachment=False, mimetype=doc["mime_type"])


@bp.route("/api/documents/<int:id_document>/pdf", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def telecharger_pdf(id_document):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Document WHERE id_document = %s", (id_document,))
    doc = cur.fetchone()
    cur.close(); db.close()
    if not doc:
        return jsonify({"error": "Document introuvable"}), 404

    path = os.path.join(UPLOAD_DIR, doc["nom_stockage"])
    if not os.path.exists(path):
        return jsonify({"error": "Fichier introuvable sur le serveur"}), 404

    nom_pdf = doc["nom_original"].rsplit(".", 1)[0] + ".pdf"
    mime = doc["mime_type"] or ""

    if "pdf" in mime:
        return send_file(path, download_name=nom_pdf,
                         as_attachment=True, mimetype="application/pdf")

    # Conversion image → PDF
    from fpdf import FPDF
    from PIL import Image

    img = Image.open(path)
    w_px, h_px = img.size
    dpi = 96
    w_mm = w_px * 25.4 / dpi
    h_mm = h_px * 25.4 / dpi

    pdf = FPDF(unit="mm", format=(w_mm, h_mm))
    pdf.add_page()
    pdf.image(path, x=0, y=0, w=w_mm, h=h_mm)

    buf = io.BytesIO(pdf.output())
    buf.seek(0)
    return send_file(buf, download_name=nom_pdf,
                     as_attachment=True, mimetype="application/pdf")


@bp.route("/api/documents/<int:id_document>", methods=["DELETE"])
@login_required
@role_required("medecin", "secretaire")
def delete_document(id_document):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT nom_stockage FROM Document WHERE id_document = %s", (id_document,))
    doc = cur.fetchone()
    if not doc:
        cur.close(); db.close()
        return jsonify({"error": "Document introuvable"}), 404

    path = os.path.join(UPLOAD_DIR, doc["nom_stockage"])
    if os.path.exists(path):
        os.remove(path)

    cur.execute("DELETE FROM Document WHERE id_document = %s", (id_document,))
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Document supprimé"})

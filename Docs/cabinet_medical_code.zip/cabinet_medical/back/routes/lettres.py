from flask import Blueprint, request, jsonify
from db import get_db, to_dict
from auth import login_required, role_required

bp = Blueprint("lettres", __name__)

@bp.route("/api/lettres/<int:id_lettre>", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def get_lettre(id_lettre):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Lettre_hospitalisation WHERE id_lettre = %s", (id_lettre,))
    lettre = cur.fetchone()
    cur.close(); db.close()
    if not lettre:
        return jsonify({"error": "Lettre introuvable"}), 404
    return jsonify(to_dict(lettre))


@bp.route("/api/consultations/<int:id_consultation>/lettre", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def get_lettre_by_consultation(id_consultation):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Lettre_hospitalisation WHERE id_consultation = %s", (id_consultation,))
    lettres = [to_dict(r) for r in cur.fetchall()]
    cur.close(); db.close()
    return jsonify(lettres)


@bp.route("/api/lettres", methods=["POST"])
@login_required
@role_required("medecin")
def create_lettre():
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        """INSERT INTO Lettre_hospitalisation
           (date_lettre, motif, contenu, service_destination, service_envoi, id_consultation)
           VALUES (%s,%s,%s,%s,%s,%s)""",
        (data["date_lettre"], data.get("motif"), data.get("contenu"),
         data.get("service_destination"), data.get("service_envoi"), data["id_consultation"])
    )
    db.commit()
    id_lettre = cur.lastrowid
    cur.close(); db.close()
    return jsonify({"message": "Lettre créée", "id_lettre": id_lettre}), 201


@bp.route("/api/lettres/<int:id_lettre>", methods=["PUT"])
@login_required
@role_required("medecin")
def update_lettre(id_lettre):
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        """UPDATE Lettre_hospitalisation
           SET motif=%s, contenu=%s, service_destination=%s, service_envoi=%s
           WHERE id_lettre=%s""",
        (data.get("motif"), data.get("contenu"),
         data.get("service_destination"), data.get("service_envoi"), id_lettre)
    )
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Lettre mise à jour"})


@bp.route("/api/lettres/<int:id_lettre>", methods=["DELETE"])
@login_required
@role_required("medecin")
def delete_lettre(id_lettre):
    db = get_db(); cur = db.cursor()
    cur.execute("DELETE FROM Lettre_hospitalisation WHERE id_lettre = %s", (id_lettre,))
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Lettre supprimée"})
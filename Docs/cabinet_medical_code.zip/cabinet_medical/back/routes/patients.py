from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from db import get_db, to_dict
from auth import login_required, role_required

bp = Blueprint("patients", __name__)

@bp.route("/api/patients", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def get_patients():
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("""
        SELECT p.*, u.nom, u.prenom, u.email, u.login
        FROM Patient p
        JOIN Utilisateur u ON p.id_utilisateur = u.id_utilisateur
        ORDER BY u.nom, u.prenom
    """)
    patients = [to_dict(r) for r in cur.fetchall()]
    cur.close(); db.close()
    return jsonify(patients)


@bp.route("/api/patients/<int:id_patient>", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def get_patient(id_patient):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("""
        SELECT p.*, u.nom, u.prenom, u.email, u.login
        FROM Patient p
        JOIN Utilisateur u ON p.id_utilisateur = u.id_utilisateur
        WHERE p.id_patient = %s
    """, (id_patient,))
    patient = cur.fetchone()
    cur.close(); db.close()
    if not patient:
        return jsonify({"error": "Patient introuvable"}), 404
    return jsonify(to_dict(patient))


@bp.route("/api/patients", methods=["POST"])
@login_required
@role_required("medecin", "secretaire")
def create_patient():
    data = request.json
    db = get_db(); cur = db.cursor()
    hashed = generate_password_hash(data["mot_de_passe"])
    cur.execute(
        "INSERT INTO Utilisateur (login, nom, prenom, email, mot_de_passe) VALUES (%s,%s,%s,%s,%s)",
        (data["login"], data["nom"], data["prenom"], data["email"], hashed)
    )
    id_utilisateur = cur.lastrowid
    cur.execute(
        """INSERT INTO Patient (numero_secu, date_de_naissance, sexe, adresse, telephone, id_utilisateur)
           VALUES (%s,%s,%s,%s,%s,%s)""",
        (data["numero_secu"], data["date_de_naissance"], data["sexe"],
         data.get("adresse"), data.get("telephone"), id_utilisateur)
    )
    db.commit()
    id_patient = cur.lastrowid
    cur.close(); db.close()
    return jsonify({"message": "Patient créé", "id_patient": id_patient}), 201


@bp.route("/api/patients/<int:id_patient>", methods=["PUT"])
@login_required
@role_required("medecin", "secretaire")
def update_patient(id_patient):
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        """UPDATE Patient SET numero_secu=%s, date_de_naissance=%s, sexe=%s, adresse=%s, telephone=%s
           WHERE id_patient=%s""",
        (data["numero_secu"], data["date_de_naissance"], data["sexe"],
         data.get("adresse"), data.get("telephone"), id_patient)
    )
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Patient mis à jour"})


@bp.route("/api/patients/<int:id_patient>", methods=["DELETE"])
@login_required
@role_required("secretaire")
def delete_patient(id_patient):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT id_utilisateur FROM Patient WHERE id_patient = %s", (id_patient,))
    row = cur.fetchone()
    if not row:
        cur.close(); db.close()
        return jsonify({"error": "Patient introuvable"}), 404
    cur.execute("DELETE FROM Utilisateur WHERE id_utilisateur = %s", (row["id_utilisateur"],))
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Patient supprimé"})
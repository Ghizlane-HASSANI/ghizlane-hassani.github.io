from flask import Blueprint, request, jsonify
from db import get_db, to_dict
from auth import login_required, role_required

bp = Blueprint("prescriptions", __name__)

@bp.route("/api/prescriptions", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def get_prescriptions():
    id_consultation = request.args.get("id_consultation")
    db = get_db(); cur = db.cursor(dictionary=True)
    if id_consultation:
        cur.execute("SELECT * FROM Prescription WHERE id_consultation = %s", (id_consultation,))
    else:
        cur.execute("SELECT * FROM Prescription ORDER BY date_prescription DESC")
    prescriptions = [to_dict(r) for r in cur.fetchall()]
    cur.close(); db.close()
    return jsonify(prescriptions)


@bp.route("/api/prescriptions/<int:id_prescription>", methods=["GET"])
@login_required
@role_required("medecin", "secretaire")
def get_prescription(id_prescription):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Prescription WHERE id_prescription = %s", (id_prescription,))
    p = cur.fetchone()
    cur.close(); db.close()
    if not p:
        return jsonify({"error": "Prescription introuvable"}), 404
    return jsonify(to_dict(p))


@bp.route("/api/prescriptions", methods=["POST"])
@login_required
@role_required("medecin")
def create_prescription():
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        "INSERT INTO Prescription (date_prescription, contenu, duree_traitement, id_consultation) VALUES (%s,%s,%s,%s)",
        (data["date_prescription"], data["contenu"], data.get("duree_traitement"), data["id_consultation"])
    )
    db.commit()
    id_prescription = cur.lastrowid
    cur.close(); db.close()
    return jsonify({"message": "Prescription créée", "id_prescription": id_prescription}), 201


@bp.route("/api/prescriptions/<int:id_prescription>", methods=["PUT"])
@login_required
@role_required("medecin")
def update_prescription(id_prescription):
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        "UPDATE Prescription SET contenu=%s, duree_traitement=%s WHERE id_prescription=%s",
        (data["contenu"], data.get("duree_traitement"), id_prescription)
    )
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Prescription mise à jour"})


@bp.route("/api/prescriptions/<int:id_prescription>", methods=["DELETE"])
@login_required
@role_required("medecin")
def delete_prescription(id_prescription):
    db = get_db(); cur = db.cursor()
    cur.execute("DELETE FROM Prescription WHERE id_prescription = %s", (id_prescription,))
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "Prescription supprimée"})
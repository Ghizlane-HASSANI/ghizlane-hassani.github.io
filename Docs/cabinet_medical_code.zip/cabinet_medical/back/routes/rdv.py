from flask import Blueprint, request, jsonify, g
from db import get_db, to_dict
from auth import login_required

bp = Blueprint("rdv", __name__)

@bp.route("/api/rdv", methods=["GET"])
@login_required
def get_rdv():
    db = get_db(); cur = db.cursor(dictionary=True)
    role    = g.user["role"]
    role_id = g.user["role_id"]

    if role == "medecin":
        cur.execute("SELECT * FROM Rendez_vous WHERE id_medecin = %s ORDER BY date_rdv, heure_debut", (role_id,))
    elif role == "patient":
        cur.execute("SELECT * FROM Rendez_vous WHERE id_patient = %s ORDER BY date_rdv, heure_debut", (role_id,))
    else:
        cur.execute("SELECT * FROM Rendez_vous ORDER BY date_rdv, heure_debut")

    rdvs = [to_dict(r) for r in cur.fetchall()]
    cur.close(); db.close()
    return jsonify(rdvs)


@bp.route("/api/rdv/<int:id_rdv>", methods=["GET"])
@login_required
def get_rdv_by_id(id_rdv):
    db = get_db(); cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM Rendez_vous WHERE id_rdv = %s", (id_rdv,))
    rdv = cur.fetchone()
    cur.close(); db.close()
    if not rdv:
        return jsonify({"error": "RDV introuvable"}), 404
    return jsonify(to_dict(rdv))


@bp.route("/api/rdv", methods=["POST"])
@login_required
def create_rdv():
    data = request.json
    role = g.user["role"]

    id_patient = g.user["role_id"] if role == "patient" else data.get("id_patient")
    id_medecin = data.get("id_medecin")

    if not id_patient or not id_medecin:
        return jsonify({"error": "id_patient et id_medecin requis"}), 400

    db = get_db(); cur = db.cursor(dictionary=True)

    cur.execute("""
        SELECT id_rdv FROM Rendez_vous
        WHERE id_medecin = %s AND date_rdv = %s AND statut != 'annulé'
          AND heure_debut < %s AND heure_fin > %s
    """, (id_medecin, data["date_rdv"], data["heure_fin"], data["heure_debut"]))
    if cur.fetchone():
        cur.close(); db.close()
        return jsonify({"error": "Conflit d'horaire pour ce médecin"}), 409

    cur2 = db.cursor()
    cur2.execute(
        """INSERT INTO Rendez_vous (date_rdv, heure_debut, heure_fin, statut, motif, id_patient, id_medecin)
           VALUES (%s,%s,%s,'prévu',%s,%s,%s)""",
        (data["date_rdv"], data["heure_debut"], data["heure_fin"],
         data.get("motif"), id_patient, id_medecin)
    )
    db.commit()
    id_rdv = cur2.lastrowid
    cur.close(); cur2.close(); db.close()
    return jsonify({"message": "RDV créé", "id_rdv": id_rdv}), 201


@bp.route("/api/rdv/<int:id_rdv>", methods=["PUT"])
@login_required
def update_rdv(id_rdv):
    data = request.json
    db = get_db(); cur = db.cursor()
    cur.execute(
        "UPDATE Rendez_vous SET date_rdv=%s, heure_debut=%s, heure_fin=%s, statut=%s, motif=%s WHERE id_rdv=%s",
        (data["date_rdv"], data["heure_debut"], data["heure_fin"],
         data.get("statut", "prévu"), data.get("motif"), id_rdv)
    )
    db.commit(); cur.close(); db.close()
    return jsonify({"message": "RDV mis à jour"})


@bp.route("/api/rdv/<int:id_rdv>", methods=["DELETE"])
@login_required
def delete_rdv(id_rdv):
    role    = g.user["role"]
    role_id = g.user["role_id"]
    db = get_db(); cur = db.cursor(dictionary=True)

    cur.execute("SELECT id_patient FROM Rendez_vous WHERE id_rdv = %s", (id_rdv,))
    rdv = cur.fetchone()
    if not rdv:
        cur.close(); db.close()
        return jsonify({"error": "RDV introuvable"}), 404

    if role == "patient" and rdv["id_patient"] != role_id:
        cur.close(); db.close()
        return jsonify({"error": "Accès refusé"}), 403

    cur2 = db.cursor()
    cur2.execute("DELETE FROM Rendez_vous WHERE id_rdv = %s", (id_rdv,))
    db.commit(); cur.close(); cur2.close(); db.close()
    return jsonify({"message": "RDV supprimé"})
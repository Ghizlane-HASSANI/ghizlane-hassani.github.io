-- ============================================
-- BASE DE DONNÉES - Cabinet Médical de Ville
-- ============================================

CREATE DATABASE IF NOT EXISTS cabinet_medical CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cabinet_medical;

-- ============================================
-- 1. UTILISATEUR (table centrale)
-- ============================================
CREATE TABLE Utilisateur (
    id_utilisateur  INT AUTO_INCREMENT PRIMARY KEY,
    login           VARCHAR(100) NOT NULL UNIQUE,
    nom             VARCHAR(100) NOT NULL,
    prenom          VARCHAR(100) NOT NULL,
    email           VARCHAR(150) NOT NULL UNIQUE,
    mot_de_passe    VARCHAR(255) NOT NULL  -- hashé avec bcrypt côté Flask
);

-- ============================================
-- 2. MÉDECIN
-- ============================================
CREATE TABLE Medecin (
    id_medecin      INT AUTO_INCREMENT PRIMARY KEY,
    specialite      VARCHAR(100),
    numero_rpps     VARCHAR(11) NOT NULL UNIQUE,
    id_utilisateur  INT NOT NULL UNIQUE,
    FOREIGN KEY (id_utilisateur) REFERENCES Utilisateur(id_utilisateur)
        ON DELETE CASCADE
);

-- ============================================
-- 3. SECRÉTAIRE
-- ============================================
CREATE TABLE Secretaire (
    id_secretaire   INT AUTO_INCREMENT PRIMARY KEY,
    numero_poste    VARCHAR(20),
    service         VARCHAR(100),
    id_utilisateur  INT NOT NULL UNIQUE,
    FOREIGN KEY (id_utilisateur) REFERENCES Utilisateur(id_utilisateur)
        ON DELETE CASCADE
);

-- ============================================
-- 4. PATIENT
-- ============================================
CREATE TABLE Patient (
    id_patient          INT AUTO_INCREMENT PRIMARY KEY,
    numero_secu         VARCHAR(21) NOT NULL UNIQUE,
    date_de_naissance   DATE NOT NULL,
    sexe                ENUM('M', 'F', 'Autre') NOT NULL,
    adresse             VARCHAR(255),
    telephone           VARCHAR(20),
    id_utilisateur      INT NOT NULL UNIQUE,
    FOREIGN KEY (id_utilisateur) REFERENCES Utilisateur(id_utilisateur)
        ON DELETE CASCADE
);

-- ============================================
-- 5. RENDEZ-VOUS
-- ============================================
CREATE TABLE Rendez_vous (
    id_rdv          INT AUTO_INCREMENT PRIMARY KEY,
    date_rdv        DATE NOT NULL,
    heure_debut     TIME NOT NULL,
    heure_fin       TIME NOT NULL,
    statut          ENUM('prévu', 'annulé', 'effectué') NOT NULL DEFAULT 'prévu',
    date_creation   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    motif           VARCHAR(255),
    id_patient      INT NOT NULL,
    id_medecin      INT NOT NULL,
    FOREIGN KEY (id_patient) REFERENCES Patient(id_patient)
        ON DELETE CASCADE,
    FOREIGN KEY (id_medecin) REFERENCES Medecin(id_medecin)
        ON DELETE CASCADE
);

-- ============================================
-- 6. CONSULTATION
-- ============================================
CREATE TABLE Consultation (
    id_consultation     INT AUTO_INCREMENT PRIMARY KEY,
    date_consultation   DATE NOT NULL,
    heure_debut         TIME NOT NULL,
    heure_fin           TIME,
    symptomes           TEXT,
    observations        TEXT,
    notes               TEXT,
    diagnostic          TEXT,
    id_rdv              INT UNIQUE,      -- (0,1) un RDV donne lieu à 0 ou 1 consultation
    id_patient          INT NOT NULL,
    id_medecin          INT NOT NULL,
    FOREIGN KEY (id_rdv) REFERENCES Rendez_vous(id_rdv)
        ON DELETE SET NULL,
    FOREIGN KEY (id_patient) REFERENCES Patient(id_patient)
        ON DELETE CASCADE,
    FOREIGN KEY (id_medecin) REFERENCES Medecin(id_medecin)
        ON DELETE CASCADE
);

-- ============================================
-- 7. ANALYSES DE LABORATOIRE
-- ============================================
CREATE TABLE Analyse (
    id_analyse         INT AUTO_INCREMENT PRIMARY KEY,
    type_analyse       VARCHAR(150) NOT NULL,
    laboratoire        VARCHAR(150),
    date_analyse       DATE,
    resultat           TEXT,
    commentaires       TEXT,
    id_patient         INT NOT NULL,
    id_medecin         INT,
    FOREIGN KEY (id_patient) REFERENCES Patient(id_patient)
        ON DELETE CASCADE,
    FOREIGN KEY (id_medecin) REFERENCES Medecin(id_medecin)
        ON DELETE SET NULL
);

-- ============================================
-- 8. PRESCRIPTION
-- ============================================
CREATE TABLE Prescription (
    id_prescription     INT AUTO_INCREMENT PRIMARY KEY,
    date_prescription   DATE NOT NULL,
    contenu             TEXT NOT NULL,
    duree_traitement    VARCHAR(100),
    id_consultation     INT NOT NULL,
    FOREIGN KEY (id_consultation) REFERENCES Consultation(id_consultation)
        ON DELETE CASCADE
);

-- ============================================
-- 8. LETTRE D'HOSPITALISATION
-- ============================================
CREATE TABLE Lettre_hospitalisation (
    id_lettre           INT AUTO_INCREMENT PRIMARY KEY,
    date_lettre         DATE NOT NULL,
    motif               VARCHAR(255),
    contenu             TEXT,
    service_destination VARCHAR(150),
    service_envoi       VARCHAR(150),
    id_consultation     INT NOT NULL,
    FOREIGN KEY (id_consultation) REFERENCES Consultation(id_consultation)
        ON DELETE CASCADE
);

-- ============================================
-- 9. ALLERGIE
-- ============================================
CREATE TABLE Allergie (
    id_allergie         INT AUTO_INCREMENT PRIMARY KEY,
    libelle             VARCHAR(150) NOT NULL,
    description         TEXT,
    date_declaration    DATE,
    statut_allergie     ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    id_patient          INT NOT NULL,
    FOREIGN KEY (id_patient) REFERENCES Patient(id_patient)
        ON DELETE CASCADE
);

-- ============================================
-- 10. ANTÉCÉDENT
-- ============================================
CREATE TABLE Antecedent (
    id_antecedent       INT AUTO_INCREMENT PRIMARY KEY,
    libelle             VARCHAR(150) NOT NULL,
    description         TEXT,
    date_declaration    DATE,
    statut_antecedent   ENUM('actif', 'résolu') NOT NULL DEFAULT 'actif',
    id_patient          INT NOT NULL,
    FOREIGN KEY (id_patient) REFERENCES Patient(id_patient)
        ON DELETE CASCADE
);

-- ============================================
-- 11. DOCUMENT MÉDICAL
-- ============================================
CREATE TABLE Document (
    id_document     INT AUTO_INCREMENT PRIMARY KEY,
    nom_original    VARCHAR(255) NOT NULL,
    nom_stockage    VARCHAR(255) NOT NULL UNIQUE,
    type_document   ENUM('analyse', 'imagerie', 'compte_rendu', 'autre') NOT NULL DEFAULT 'autre',
    description     TEXT,
    date_upload     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    mime_type       VARCHAR(100),
    id_patient      INT NOT NULL,
    FOREIGN KEY (id_patient) REFERENCES Patient(id_patient)
        ON DELETE CASCADE
);
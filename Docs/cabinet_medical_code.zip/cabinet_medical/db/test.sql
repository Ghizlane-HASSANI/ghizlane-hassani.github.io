-- ============================================
-- DONNÉES DE TEST - Cabinet Médical de Ville
-- ============================================

USE cabinet_medical;

-- ============================================
-- 1. UTILISATEURS
-- ============================================
INSERT INTO Utilisateur (login, nom, prenom, email, mot_de_passe) VALUES
-- Médecins
('SM1542112',  'Martin',    'Sophie',   'sophie.martin@cabinet.fr',    'scrypt:32768:8:1$2B0eoaw8taa1NawG$8a06fd0860a7039cf803ba4902c434f8b664c3f56abc961e41c6725bf49bf83f987dc1f95b845a1fb0e607cadafb752fe0e6a841662913527e597984bdc07c2f'),
('PL8934567',  'Leroy',     'Paul',     'paul.leroy@cabinet.fr',       'scrypt:32768:8:1$2B0eoaw8taa1NawG$8a06fd0860a7039cf803ba4902c434f8b664c3f56abc961e41c6725bf49bf83f987dc1f95b845a1fb0e607cadafb752fe0e6a841662913527e597984bdc07c2f'),
('LN2367891',  'Nguyen',    'Linh',     'linh.nguyen@cabinet.fr',      'scrypt:32768:8:1$2B0eoaw8taa1NawG$8a06fd0860a7039cf803ba4902c434f8b664c3f56abc961e41c6725bf49bf83f987dc1f95b845a1fb0e607cadafb752fe0e6a841662913527e597984bdc07c2f'),
-- Secrétaires
('MD7891234',  'Dupont',    'Marie',    'marie.dupont@cabinet.fr',     'scrypt:32768:8:1$2B0eoaw8taa1NawG$8a06fd0860a7039cf803ba4902c434f8b664c3f56abc961e41c6725bf49bf83f987dc1f95b845a1fb0e607cadafb752fe0e6a841662913527e597984bdc07c2f'),
('JB4563210',  'Bernard',   'Julien',   'julien.bernard@cabinet.fr',   'scrypt:32768:8:1$2B0eoaw8taa1NawG$8a06fd0860a7039cf803ba4902c434f8b664c3f56abc961e41c6725bf49bf83f987dc1f95b845a1fb0e607cadafb752fe0e6a841662913527e597984bdc07c2f'),
-- Patients
('CD9012345',  'Durand',    'Claire',   'claire.durand@gmail.com',     'scrypt:32768:8:1$2B0eoaw8taa1NawG$8a06fd0860a7039cf803ba4902c434f8b664c3f56abc961e41c6725bf49bf83f987dc1f95b845a1fb0e607cadafb752fe0e6a841662913527e597984bdc07c2f'),
('JM3456789',  'Moreau',    'Jacques',  'jacques.moreau@hotmail.fr',   'scrypt:32768:8:1$2B0eoaw8taa1NawG$8a06fd0860a7039cf803ba4902c434f8b664c3f56abc961e41c6725bf49bf83f987dc1f95b845a1fb0e607cadafb752fe0e6a841662913527e597984bdc07c2f'),
('EP6781230',  'Petit',     'Emma',     'emma.petit@gmail.com',        'scrypt:32768:8:1$2B0eoaw8taa1NawG$8a06fd0860a7039cf803ba4902c434f8b664c3f56abc961e41c6725bf49bf83f987dc1f95b845a1fb0e607cadafb752fe0e6a841662913527e597984bdc07c2f'),
('LT1237896',  'Thomas',    'Luc',      'luc.thomas@outlook.com',      'scrypt:32768:8:1$2B0eoaw8taa1NawG$8a06fd0860a7039cf803ba4902c434f8b664c3f56abc961e41c6725bf49bf83f987dc1f95b845a1fb0e607cadafb752fe0e6a841662913527e597984bdc07c2f'),
('IR8904561',  'Robert',    'Isabelle', 'isabelle.robert@gmail.com',   'scrypt:32768:8:1$2B0eoaw8taa1NawG$8a06fd0860a7039cf803ba4902c434f8b664c3f56abc961e41c6725bf49bf83f987dc1f95b845a1fb0e607cadafb752fe0e6a841662913527e597984bdc07c2f'),
('AS5670123',  'Simon',     'Antoine',  'antoine.simon@free.fr',       'scrypt:32768:8:1$2B0eoaw8taa1NawG$8a06fd0860a7039cf803ba4902c434f8b664c3f56abc961e41c6725bf49bf83f987dc1f95b845a1fb0e607cadafb752fe0e6a841662913527e597984bdc07c2f');

-- ============================================
-- 2. MÉDECINS
-- ============================================
INSERT INTO Medecin (specialite, numero_rpps, id_utilisateur) VALUES
('Médecine générale',  '10003456789', 1),
('Cardiologie',        '10003456790', 2),
('Pédiatrie',          '10003456791', 3);

-- ============================================
-- 3. SECRÉTAIRES
-- ============================================
INSERT INTO Secretaire (numero_poste, service, id_utilisateur) VALUES
('01 23 45 67 89', 'Accueil',       4),
('01 23 45 67 90', 'Administratif', 5);

-- ============================================
-- 4. PATIENTS
-- ============================================
INSERT INTO Patient (numero_secu, date_de_naissance, sexe, adresse, telephone, id_utilisateur) VALUES
('2 85 04 75 123 456 78', '1985-04-12', 'F', '14 rue des Lilas, 75010 Paris',         '06 12 34 56 78', 6),
('1 58 09 69 234 567 89', '1958-09-03', 'M', '27 avenue Victor Hugo, 69002 Lyon',     '06 23 45 67 89', 7),
('2 01 02 13 345 678 90', '2001-02-20', 'F', '5 impasse du Moulin, 13005 Marseille',  '07 34 56 78 90', 8),
('1 76 11 44 456 789 01', '1976-11-08', 'M', '31 boulevard Gambetta, 44000 Nantes',   '06 45 67 89 01', 9),
('2 92 07 67 567 890 12', '1992-07-25', 'F', '8 rue du Faubourg, 67000 Strasbourg',   '07 56 78 90 12', 10),
('1 65 03 31 678 901 23', '1965-03-15', 'M', '19 chemin des Roses, 31000 Toulouse',   '06 67 89 01 23', 11);

-- ============================================
-- 5. RENDEZ-VOUS
-- ============================================
INSERT INTO Rendez_vous (date_rdv, heure_debut, heure_fin, statut, motif, id_patient, id_medecin) VALUES
('2025-01-10', '09:00', '09:30', 'effectué', 'Suivi diabète',                   1, 1),
('2025-01-15', '10:30', '11:00', 'effectué', 'Consultation cardiologique',       2, 2),
('2025-01-22', '14:00', '14:30', 'effectué', 'Rhume persistant',                 3, 3),
('2025-02-05', '08:30', '09:00', 'effectué', 'Renouvellement ordonnance',        4, 1),
('2025-02-18', '11:00', '11:30', 'effectué', 'Bilan annuel',                     5, 2),
('2025-03-03', '15:00', '15:30', 'effectué', 'Douleurs articulaires',            6, 1),
('2025-03-12', '09:30', '10:00', 'effectué', 'Contrôle tension',                1, 2),
('2025-04-01', '14:30', '15:00', 'effectué', 'Fièvre enfant',                    3, 3),
('2025-02-20', '16:00', '16:30', 'annulé',   'Consultation dermatologique',      2, 1),
('2025-03-25', '10:00', '10:30', 'annulé',   'Suivi post-opératoire',            4, 2),
('2026-05-06', '09:00', '09:30', 'prévu',    'Renouvellement traitement',        1, 1),
('2026-05-07', '11:00', '11:30', 'prévu',    'Bilan cardiaque de contrôle',      2, 2),
('2026-05-10', '14:00', '14:30', 'prévu',    'Vaccination',                      3, 3),
('2026-05-14', '08:30', '09:00', 'prévu',    'Résultats analyses',               5, 1);

-- ============================================
-- 6. CONSULTATIONS
-- ============================================
INSERT INTO Consultation (date_consultation, heure_debut, heure_fin, symptomes, observations, notes, diagnostic, id_rdv, id_patient, id_medecin) VALUES
('2025-01-10', '09:00', '09:25', 'Fatigue, soif excessive, mictions fréquentes', 'Glycémie à jeun : 1,52 g/L. TA 130/80 mmHg.', 'Patient suivi depuis 3 ans pour diabète type 2. Observance correcte.', 'Diabète de type 2 déséquilibré. Adaptation du traitement nécessaire.', 1, 1, 1),
('2025-01-15', '10:30', '11:00', 'Essoufflement à l''effort, palpitations occasionnelles', 'ECG normal. Auscultation : souffle systolique discret grade 2/6.', 'Antécédent familial de cardiopathie ischémique.', 'Insuffisance mitrale légère. Surveillance à 6 mois.', 2, 2, 2),
('2025-01-22', '14:00', '14:20', 'Rhinorrhée, toux sèche, légère fièvre (38,1°C)', 'Gorge légèrement érythémateuse. Pas d''adénopathie.', 'Entourage familial atteint de rhume. Pas de signe de gravité.', 'Rhinopharyngite virale bénigne.', 3, 3, 3),
('2025-02-05', '08:30', '08:55', 'Pas de symptôme particulier. Renouvellement ordonnance.', 'TA 128/78 mmHg. Poids stable. Pas d''hypoglycémie signalée.', 'Équilibre glycémique amélioré depuis modification du traitement.', 'Diabète de type 2 équilibré.', 4, 4, 1),
('2025-02-18', '11:00', '11:30', 'Bilan annuel, pas de plainte fonctionnelle', 'ECG : rythme sinusal régulier. Echo cœur : FEVG 60%. TA 125/75.', 'Patiente sportive, bon hygiène de vie. Cholestérol LDL 1,2 g/L.', 'Bilan cardiologique annuel normal.', 5, 5, 2),
('2025-03-03', '15:00', '15:28', 'Douleurs genoux bilatérales, raideur matinale < 30 min', 'Épanchement discret genou droit. Pas de déformation articulaire.', 'Radiographie genou à prescrire. IMC 27,5.', 'Gonarthrose débutante bilatérale.', 6, 6, 1),
('2025-03-12', '09:30', '09:50', 'Légères céphalées, sensation de tête lourde', 'TA 148/95 mmHg en consultation, confirmée à domicile par automesure.', 'Pas d''atteinte d''organe cible connue. Traitement en cours à optimiser.', 'HTA non contrôlée. Majoration du traitement antihypertenseur.', 7, 1, 2),
('2025-04-01', '14:30', '14:50', 'Fièvre 39°C depuis 48h, douleurs à la déglutition', 'Amygdales érythémateuses avec dépôts. TDR streptocoque positif.', 'Allergie pénicilline documentée — alternative prescrite.', 'Angine à streptocoque. Traitement antibiotique adapté.', 8, 3, 3),
('2025-03-20', '16:30', '16:55', 'Douleur thoracique atypique, stress professionnel intense', 'ECG normal. Pas de signe de gravité cardiaque.', 'Contexte anxieux évident. Proposer suivi psychologique.', 'Douleur thoracique fonctionnelle. Anxiété.', NULL, 2, 1);

-- ============================================
-- 7. ANALYSES DE LABORATOIRE
-- ============================================
INSERT INTO Analyse (type_analyse, laboratoire, date_analyse, resultat, commentaires, id_patient, id_medecin) VALUES
('Hémogramme complet', 'Laboratoire BioParis',  '2025-01-09', 'Globules rouges normaux, légère anémie ferriprive', 'Faire un contrôle sous fer oral dans 1 mois.', 1, 1),
('Bilan lipidique',    'Laboratoire Lyonest',   '2025-01-16', 'LDL élevé, HDL faible',                            'Modification du régime alimentaire et reprise en 3 mois.', 2, 2);

-- ============================================
-- 8. PRESCRIPTIONS
-- ============================================
INSERT INTO Prescription (date_prescription, contenu, duree_traitement, id_consultation) VALUES
('2025-01-10', 'Metformine 1000 mg : 1 comprimé matin et soir au cours des repas\nGlipizide 5 mg : 1 comprimé le matin\nContrôle glycémique mensuel à domicile', '3 mois, renouvellement sur bilan', 1),
('2025-01-15', 'Bisoprolol 2,5 mg : 1 comprimé par jour le matin\nAspégic 75 mg : 1 sachet par jour\nEcho-Doppler cardiaque dans 6 mois', '6 mois', 2),
('2025-01-22', 'Doliprane 1000 mg : 1 comprimé toutes les 6h si fièvre > 38,5°C\nNasacort spray nasal : 2 pulvérisations par narine matin et soir\nRepos, hydratation', '7 jours', 3),
('2025-02-05', 'Metformine 1000 mg : 1 comprimé matin et soir (renouvellement)\nGlipizide 5 mg : 1 comprimé le matin (renouvellement)\nHbA1c dans 3 mois', '3 mois', 4),
('2025-03-03', 'Paracétamol 500 mg : 2 comprimés 3 fois par jour si douleur\nDiclofénac gel : appliquer sur les genoux 2 fois par jour\nKinésithérapie : 10 séances\nRadiographie genoux face et profil en charge', '1 mois, réévaluation', 6),
('2025-03-12', 'Amlodipine 10 mg : 1 comprimé par jour\nRamipril 5 mg : 1 comprimé par jour (majoration dose)\nAutomesure tensionnelle matin et soir pendant 1 semaine\nBilan rénal et ionogramme', '1 mois, puis bilan', 7),
('2025-04-01', 'Azithromycine 500 mg : 1 comprimé par jour pendant 3 jours\nDoliprane 1000 mg si fièvre\nReste à domicile jusqu''à apyrexie', '3 jours d''antibiotique', 8);

-- ============================================
-- 9. LETTRES D'HOSPITALISATION
-- ============================================
INSERT INTO Lettre_hospitalisation (date_lettre, motif, contenu, service_destination, service_envoi, id_consultation) VALUES
('2025-01-15', 'Exploration insuffisance mitrale', 'Je vous adresse M. Jacques Moreau, 66 ans, pour une évaluation spécialisée d''une insuffisance mitrale légère découverte lors d''un bilan de routine. Souffle systolique grade 2/6, ECG normal. Pas de traitement anticoagulant en cours. Espérant votre avis éclairé, je reste à votre disposition.', 'Service de Cardiologie — CHU de Lyon', 'Cabinet Dr Leroy — Cardiologue', 2),
('2025-03-03', 'Bilan gonarthrose bilatérale débutante', 'Je vous adresse M. Antoine Simon, 60 ans, pour prise en charge d''une gonarthrose bilatérale débutante avec épanchement discret du genou droit. Radiographies en cours. Kinésithérapie débutée. Patient en surpoids léger (IMC 27,5). Merci pour votre avis et orientation thérapeutique.', 'Service de Rhumatologie — CHU Toulouse', 'Cabinet Dr Martin — Médecine générale', 6);

-- ============================================
-- 10. DOCUMENTS MÉDICAUX
-- ============================================
INSERT INTO Document (nom_original, nom_stockage, type_document, description, mime_type, id_patient) VALUES
('bilan_sanguin_claire_durand.pdf',   'doc_001_bilan_sanguin.pdf',   'analyse',      'Bilan sanguin complet — janvier 2025',          'application/pdf', 1),
('radio_genou_antoine_simon.jpg',     'doc_002_radio_genou.jpg',     'imagerie',     'Radiographie genoux bilatéraux en charge',       'image/jpeg',      6),
('cr_cardio_jacques_moreau.pdf',      'doc_003_cr_cardio.pdf',       'compte_rendu', 'Compte-rendu cardiologue — insuffisance mitrale', 'application/pdf', 2),
('bilan_thyroide_isabelle_robert.pdf','doc_004_bilan_thyroide.pdf',  'analyse',      'TSH, T3, T4 — contrôle hypothyroïdie',           'application/pdf', 5),
('echo_coeur_emma_petit.pdf',         'doc_005_echo_coeur.pdf',      'compte_rendu', 'Échographie cardiaque — bilan annuel',            'application/pdf', 3);

-- ============================================
-- 11. ALLERGIES
-- ============================================
INSERT INTO Allergie (libelle, description, date_declaration, statut_allergie, id_patient) VALUES
('Pénicilline',  'Rash cutané généralisé lors de prise d''amoxicilline en 2010. Confirmée par allergologue.', '2010-06-15', 'active',   3),
('Arachides',    'Urticaire et œdème labial. Porte un stylo auto-injecteur d''adrénaline.',                   '2015-03-20', 'active',   5),
('Ibuprofène',   'Bronchospasme lors de prise d''ibuprofène. Éviction de tous les AINS.',                     '2018-11-05', 'active',   1),
('Latex',        'Réaction cutanée au contact de gants en latex.',                                            '2012-07-10', 'active',   2),
('Aspirine',     'Urticaire diffuse. Ancienne allergie documentée, tolérée à faible dose depuis 2022.',       '2008-04-22', 'inactive', 6);

-- ============================================
-- 11. ANTÉCÉDENTS
-- ============================================
INSERT INTO Antecedent (libelle, description, date_declaration, statut_antecedent, id_patient) VALUES
('Diabète de type 2',         'Diagnostiqué en 2022. Traitement oral. Suivi trimestriel.',                         '2022-03-10', 'actif',  1),
('HTA',                       'Hypertension artérielle essentielle. Traitement antihypertenseur depuis 2020.',      '2020-09-14', 'actif',  1),
('Infarctus du myocarde',     'IDM inférieur en 2019. Stent posé sur CD. Traitement au long cours.',                '2019-07-22', 'actif',  2),
('Appendicectomie',           'Appendicite aiguë opérée en 1998. Pas de complication.',                             '1998-05-03', 'résolu', 2),
('Asthme allergique',         'Asthme modéré persistant. Traitement de fond par corticoïde inhalé.',                '2005-02-18', 'actif',  3),
('Fracture du poignet droit', 'Fracture radius distal suite à une chute. Ostéosynthèse. Consolidée.',               '2015-12-01', 'résolu', 4),
('Hypothyroïdie',             'Hypothyroïdie auto-immune (Hashimoto). Levothyrox 75 µg par jour.',                 '2018-06-20', 'actif',  5),
('Dépression épisodique',     'Deux épisodes dépressifs traités. Actuellement en rémission sans traitement.',       '2016-01-10', 'résolu', 5),
('Gonarthrose bilatérale',    'Arthrose débutante des deux genoux. Kinésithérapie et antalgiques.',                 '2025-03-03', 'actif',  6),
('Hypertension artérielle',   'HTA découverte lors d''un bilan. Traitement en cours d''optimisation.',              '2024-11-20', 'actif',  2);

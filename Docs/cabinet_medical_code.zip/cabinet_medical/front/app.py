from flask import Flask, render_template, request, redirect, url_for, session
import requests
import os

app = Flask(__name__)
app.secret_key = "cabinet_medical_front_secret"

API_URL = os.environ.get("API_URL", "http://back:5000")

def api_get(path, token=None, params=None):
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.get(f"{API_URL}{path}", headers=headers, params=params)
        return r.json(), r.status_code
    except Exception as e:
        return {"error": str(e)}, 500

def api_post(path, data, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.post(f"{API_URL}{path}", json=data, headers=headers)
        return r.json(), r.status_code
    except Exception as e:
        return {"error": str(e)}, 500

def api_put(path, data, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.put(f"{API_URL}{path}", json=data, headers=headers)
        return r.json(), r.status_code
    except Exception as e:
        return {"error": str(e)}, 500

def api_delete(path, token=None):
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.delete(f"{API_URL}{path}", headers=headers)
        return r.json(), r.status_code
    except Exception as e:
        return {"error": str(e)}, 500

def api_upload(path, fichier, form_data, token=None):
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        files = {"fichier": (fichier.filename, fichier.stream, fichier.content_type)}
        r = requests.post(f"{API_URL}{path}", files=files, data=form_data, headers=headers)
        return r.json(), r.status_code
    except Exception as e:
        return {"error": str(e)}, 500

def login_required_session(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if "token" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated

# ─── AUTH ────────────────────────────────────────────────────────────────────

@app.route("/", methods=["GET"])
def index():
    if "token" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        data = {"login": request.form["login"], "mot_de_passe": request.form["mot_de_passe"]}
        result, status = api_post("/api/login", data)
        if status == 200:
            session["token"] = result["token"]
            session["role"]  = result["role"]
            session["nom"]   = result["nom"]
            session["prenom"] = result["prenom"]
            return redirect(url_for("dashboard"))
        else:
            error = result.get("error", "Erreur de connexion")
    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ─── DASHBOARD ───────────────────────────────────────────────────────────────

@app.route("/dashboard")
@login_required_session
def dashboard():
    token = session["token"]
    role  = session["role"]
    rdvs, _ = api_get("/api/rdv", token)
    patients = []
    if role in ("medecin", "secretaire"):
        patients, _ = api_get("/api/patients", token)
    return render_template("dashboard.html",
        role=role, nom=session["nom"], prenom=session["prenom"],
        rdvs=rdvs if isinstance(rdvs, list) else [],
        patients=patients if isinstance(patients, list) else [])

# ─── PATIENTS ────────────────────────────────────────────────────────────────

@app.route("/patients")
@login_required_session
def patients():
    token = session["token"]
    data, _ = api_get("/api/patients", token)
    return render_template("patients.html",
        patients=data if isinstance(data, list) else [],
        role=session["role"], nom=session["nom"], prenom=session["prenom"])

@app.route("/patients/<int:id_patient>")
@login_required_session
def patient_detail(id_patient):
    token = session["token"]
    patient, _       = api_get(f"/api/patients/{id_patient}", token)
    allergies, _     = api_get(f"/api/patients/{id_patient}/allergies", token)
    antecedents, _   = api_get(f"/api/patients/{id_patient}/antecedents", token)
    consultations, _ = api_get("/api/consultations", token, params={"id_patient": id_patient})
    analyses, _      = api_get(f"/api/patients/{id_patient}/analyses", token)
    rdvs, _          = api_get("/api/rdv", token)
    patient_rdvs = [r for r in (rdvs if isinstance(rdvs, list) else []) if r.get("id_patient") == id_patient]
    return render_template("patient_detail.html",
        patient=patient,
        allergies=allergies if isinstance(allergies, list) else [],
        antecedents=antecedents if isinstance(antecedents, list) else [],
        consultations=consultations if isinstance(consultations, list) else [],
        analyses=analyses if isinstance(analyses, list) else [],
        rdvs=patient_rdvs,
        role=session["role"], nom=session["nom"], prenom=session["prenom"])

@app.route("/patients/nouveau", methods=["GET", "POST"])
@login_required_session
def nouveau_patient():
    token = session["token"]
    error = None
    if request.method == "POST":
        data = {
            "login": request.form["login"],
            "nom": request.form["nom"],
            "prenom": request.form["prenom"],
            "email": request.form["email"],
            "mot_de_passe": request.form["mot_de_passe"],
            "numero_secu": request.form["numero_secu"],
            "date_de_naissance": request.form["date_de_naissance"],
            "sexe": request.form["sexe"],
            "adresse": request.form.get("adresse", ""),
            "telephone": request.form.get("telephone", "")
        }
        result, status = api_post("/api/patients", data, token)
        if status == 201:
            return redirect(url_for("patients"))
        error = result.get("error", "Erreur lors de la création")
    return render_template("patient_form.html", patient=None, error=error,
        role=session["role"], nom=session["nom"], prenom=session["prenom"])

@app.route("/patients/<int:id_patient>/modifier", methods=["GET", "POST"])
@login_required_session
def modifier_patient(id_patient):
    token = session["token"]
    error = None
    patient, _ = api_get(f"/api/patients/{id_patient}", token)
    if request.method == "POST":
        data = {
            "numero_secu": request.form["numero_secu"],
            "date_de_naissance": request.form["date_de_naissance"],
            "sexe": request.form["sexe"],
            "adresse": request.form.get("adresse", ""),
            "telephone": request.form.get("telephone", "")
        }
        result, status = api_put(f"/api/patients/{id_patient}", data, token)
        if status == 200:
            return redirect(url_for("patient_detail", id_patient=id_patient))
        error = result.get("error", "Erreur lors de la modification")
    return render_template("patient_form.html", patient=patient, error=error,
        role=session["role"], nom=session["nom"], prenom=session["prenom"])

@app.route("/patients/<int:id_patient>/supprimer", methods=["POST"])
@login_required_session
def supprimer_patient(id_patient):
    token = session["token"]
    api_delete(f"/api/patients/{id_patient}", token)
    return redirect(url_for("patients"))

# ─── RENDEZ-VOUS ─────────────────────────────────────────────────────────────

@app.route("/rdv")
@login_required_session
def rdv_list():
    token = session["token"]
    rdvs, _ = api_get("/api/rdv", token)
    patients_list = []
    if session["role"] in ("medecin", "secretaire"):
        patients_list, _ = api_get("/api/patients", token)
    return render_template("rdv.html",
        rdvs=rdvs if isinstance(rdvs, list) else [],
        patients=patients_list if isinstance(patients_list, list) else [],
        role=session["role"], nom=session["nom"], prenom=session["prenom"])

@app.route("/rdv/nouveau", methods=["POST"])
@login_required_session
def nouveau_rdv():
    token = session["token"]
    data = {
        "date_rdv": request.form["date_rdv"],
        "heure_debut": request.form["heure_debut"],
        "heure_fin": request.form["heure_fin"],
        "motif": request.form.get("motif", ""),
        "id_patient": int(request.form["id_patient"]) if request.form.get("id_patient") else None,
        "id_medecin": int(request.form["id_medecin"]) if request.form.get("id_medecin") else None
    }
    api_post("/api/rdv", data, token)
    return redirect(url_for("rdv_list"))

@app.route("/rdv/<int:id_rdv>/annuler", methods=["POST"])
@login_required_session
def annuler_rdv(id_rdv):
    token = session["token"]
    rdv, _ = api_get(f"/api/rdv/{id_rdv}", token)
    if isinstance(rdv, dict) and "id_rdv" in rdv:
        rdv["statut"] = "annulé"
        api_put(f"/api/rdv/{id_rdv}", rdv, token)
    return redirect(url_for("rdv_list"))

@app.route("/rdv/<int:id_rdv>/supprimer", methods=["POST"])
@login_required_session
def supprimer_rdv(id_rdv):
    token = session["token"]
    api_delete(f"/api/rdv/{id_rdv}", token)
    return redirect(url_for("rdv_list"))

# ─── CONSULTATIONS ────────────────────────────────────────────────────────────

@app.route("/consultations")
@login_required_session
def consultations():
    token = session["token"]
    data, _ = api_get("/api/consultations", token)
    return render_template("consultations.html",
        consultations=data if isinstance(data, list) else [],
        role=session["role"], nom=session["nom"], prenom=session["prenom"])

@app.route("/consultations/<int:id_consultation>")
@login_required_session
def consultation_detail(id_consultation):
    token = session["token"]
    consultation, _ = api_get(f"/api/consultations/{id_consultation}", token)
    prescriptions, _ = api_get("/api/prescriptions", token, params={"id_consultation": id_consultation})
    lettres, _ = api_get(f"/api/consultations/{id_consultation}/lettre", token)
    return render_template("consultation_detail.html",
        consultation=consultation,
        prescriptions=prescriptions if isinstance(prescriptions, list) else [],
        lettres=lettres if isinstance(lettres, list) else [],
        role=session["role"], nom=session["nom"], prenom=session["prenom"])

@app.route("/consultations/nouvelle", methods=["GET", "POST"])
@login_required_session
def nouvelle_consultation():
    token = session["token"]
    error = None
    patients_list, _ = api_get("/api/patients", token)
    rdvs, _ = api_get("/api/rdv", token)
    if request.method == "POST":
        data = {
            "date_consultation": request.form["date_consultation"],
            "heure_debut": request.form["heure_debut"],
            "heure_fin": request.form.get("heure_fin", ""),
            "symptomes": request.form.get("symptomes", ""),
            "observations": request.form.get("observations", ""),
            "notes": request.form.get("notes", ""),
            "diagnostic": request.form.get("diagnostic", ""),
            "id_patient": int(request.form["id_patient"]),
            "id_rdv": int(request.form["id_rdv"]) if request.form.get("id_rdv") else None
        }
        result, status = api_post("/api/consultations", data, token)
        if status == 201:
            return redirect(url_for("consultations"))
        error = result.get("error", "Erreur lors de la création")
    return render_template("consultation_form.html",
        consultation=None, error=error,
        patients=patients_list if isinstance(patients_list, list) else [],
        rdvs=rdvs if isinstance(rdvs, list) else [],
        role=session["role"], nom=session["nom"], prenom=session["prenom"])

# ─── PRESCRIPTIONS ────────────────────────────────────────────────────────────

@app.route("/prescriptions/nouvelle/<int:id_consultation>", methods=["POST"])
@login_required_session
def nouvelle_prescription(id_consultation):
    token = session["token"]
    data = {
        "date_prescription": request.form["date_prescription"],
        "contenu": request.form["contenu"],
        "duree_traitement": request.form.get("duree_traitement", ""),
        "id_consultation": id_consultation
    }
    api_post("/api/prescriptions", data, token)
    return redirect(url_for("consultation_detail", id_consultation=id_consultation))

# ─── ALLERGIES ────────────────────────────────────────────────────────────────

@app.route("/allergies/nouvelle/<int:id_patient>", methods=["POST"])
@login_required_session
def nouvelle_allergie(id_patient):
    token = session["token"]
    data = {
        "libelle": request.form["libelle"],
        "description": request.form.get("description", ""),
        "date_declaration": request.form.get("date_declaration", ""),
        "statut_allergie": request.form.get("statut_allergie", "active"),
        "id_patient": id_patient
    }
    api_post("/api/allergies", data, token)
    return redirect(url_for("patient_detail", id_patient=id_patient))

@app.route("/allergies/<int:id_allergie>/supprimer/<int:id_patient>", methods=["POST"])
@login_required_session
def supprimer_allergie(id_allergie, id_patient):
    token = session["token"]
    api_delete(f"/api/allergies/{id_allergie}", token)
    return redirect(url_for("patient_detail", id_patient=id_patient))

# ─── ANTECEDENTS ──────────────────────────────────────────────────────────────

@app.route("/antecedents/nouveau/<int:id_patient>", methods=["POST"])
@login_required_session
def nouvel_antecedent(id_patient):
    token = session["token"]
    data = {
        "libelle": request.form["libelle"],
        "description": request.form.get("description", ""),
        "date_declaration": request.form.get("date_declaration", ""),
        "statut_antecedent": request.form.get("statut_antecedent", "actif"),
        "id_patient": id_patient
    }
    api_post("/api/antecedents", data, token)
    return redirect(url_for("patient_detail", id_patient=id_patient))

@app.route("/antecedents/<int:id_antecedent>/supprimer/<int:id_patient>", methods=["POST"])
@login_required_session
def supprimer_antecedent(id_antecedent, id_patient):
    token = session["token"]
    api_delete(f"/api/antecedents/{id_antecedent}", token)
    return redirect(url_for("patient_detail", id_patient=id_patient))

# ─── ANALYSES ─────────────────────────────────────────────────────────────────

@app.route("/analyses/nouvelle/<int:id_patient>", methods=["POST"])
@login_required_session
def nouvelle_analyse(id_patient):
    token = session["token"]
    data = {
        "type_analyse": request.form.get("type_analyse", ""),
        "laboratoire": request.form.get("laboratoire", ""),
        "date_analyse": request.form.get("date_analyse", ""),
        "resultat": request.form.get("resultat", ""),
        "commentaires": request.form.get("commentaires", ""),
        "id_patient": id_patient
    }
    api_post("/api/analyses", data, token)
    return redirect(url_for("patient_detail", id_patient=id_patient))

@app.route("/analyses/<int:id_analyse>/supprimer/<int:id_patient>", methods=["POST"])
@login_required_session
def supprimer_analyse(id_analyse, id_patient):
    token = session["token"]
    api_delete(f"/api/analyses/{id_analyse}", token)
    return redirect(url_for("patient_detail", id_patient=id_patient))

# ─── DOCUMENTS ───────────────────────────────────────────────────────────────

@app.route("/patients/<int:id_patient>/documents")
@login_required_session
def patient_documents(id_patient):
    token = session["token"]
    patient, _   = api_get(f"/api/patients/{id_patient}", token)
    documents, _ = api_get(f"/api/patients/{id_patient}/documents", token)
    return render_template("documents.html",
        patient=patient,
        documents=documents if isinstance(documents, list) else [],
        role=session["role"], nom=session["nom"], prenom=session["prenom"])

@app.route("/patients/<int:id_patient>/documents/upload", methods=["POST"])
@login_required_session
def upload_document(id_patient):
    token = session["token"]
    fichier = request.files.get("fichier")
    if not fichier:
        return redirect(url_for("patient_documents", id_patient=id_patient))
    form_data = {
        "type_document": request.form.get("type_document", "autre"),
        "description":   request.form.get("description", "")
    }
    api_upload(f"/api/patients/{id_patient}/documents", fichier, form_data, token)
    return redirect(url_for("patient_documents", id_patient=id_patient))

@app.route("/patients/<int:id_patient>/documents/<int:id_document>/telecharger")
@login_required_session
def telecharger_document(id_patient, id_document):
    token = session["token"]
    from flask import Response
    r = requests.get(f"{API_URL}/api/documents/{id_document}/pdf",
                     headers={"Authorization": f"Bearer {token}"}, stream=True)
    if r.status_code != 200:
        return redirect(url_for("patient_documents", id_patient=id_patient))
    return Response(
        r.iter_content(chunk_size=8192),
        content_type=r.headers.get("Content-Type", "application/pdf"),
        headers={"Content-Disposition": r.headers.get("Content-Disposition", "attachment; filename=document.pdf")}
    )

@app.route("/patients/<int:id_patient>/documents/<int:id_document>/voir")
@login_required_session
def voir_document(id_patient, id_document):
    token = session["token"]
    from flask import Response
    r = requests.get(f"{API_URL}/api/documents/{id_document}/fichier",
                     headers={"Authorization": f"Bearer {token}"}, stream=True)
    if r.status_code != 200:
        return redirect(url_for("patient_documents", id_patient=id_patient))
    return Response(
        r.iter_content(chunk_size=8192),
        content_type=r.headers.get("Content-Type", "application/octet-stream")
    )

@app.route("/patients/<int:id_patient>/documents/<int:id_document>/supprimer", methods=["POST"])
@login_required_session
def supprimer_document(id_patient, id_document):
    token = session["token"]
    api_delete(f"/api/documents/{id_document}", token)
    return redirect(url_for("patient_documents", id_patient=id_patient))

# ─── LETTRES ──────────────────────────────────────────────────────────────────

@app.route("/lettres/nouvelle/<int:id_consultation>", methods=["POST"])
@login_required_session
def nouvelle_lettre(id_consultation):
    token = session["token"]
    data = {
        "date_lettre": request.form["date_lettre"],
        "motif": request.form.get("motif", ""),
        "contenu": request.form.get("contenu", ""),
        "service_destination": request.form.get("service_destination", ""),
        "service_envoi": request.form.get("service_envoi", ""),
        "id_consultation": id_consultation
    }
    api_post("/api/lettres", data, token)
    return redirect(url_for("consultation_detail", id_consultation=id_consultation))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000, debug=True)

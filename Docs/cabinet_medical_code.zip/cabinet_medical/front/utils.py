import requests
import os
from functools import wraps
from flask import session, redirect, url_for

API_URL = os.environ.get("API_URL", "http://back:5000")

def api_get(path, token=None, params=None):
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.get(f"{API_URL}{path}", headers=headers, params=params)
        return r.json(), r.status_code
    except Exception as e:
        return {"error": str(e)}, 500

def api_post(path, data, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.post(f"{API_URL}{path}", json=data, headers=headers)
        return r.json(), r.status_code
    except Exception as e:
        return {"error": str(e)}, 500

def api_put(path, data, token=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.put(f"{API_URL}{path}", json=data, headers=headers)
        return r.json(), r.status_code
    except Exception as e:
        return {"error": str(e)}, 500

def api_delete(path, token=None):
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        r = requests.delete(f"{API_URL}{path}", headers=headers)
        return r.json(), r.status_code
    except Exception as e:
        return {"error": str(e)}, 500

def login_required_session(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "token" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated
# Système d'Information de Santé — Cabinet Médical

## Lancer le projet

### 1. Créer le fichier `.env`

Le fichier `.env` n'est pas sur GitHub (sécurité). Copie le fichier exemple :

```bash
cp .env.example .env
```

### 2. Démarrer les conteneurs

```bash
docker-compose down -v
docker-compose up --build
```

## Accès

| Service | URL |
|---------|-----|
| Site web | http://localhost:8080 |
| API backend | http://localhost:8081 |
| PhpMyAdmin | http://localhost:8083 |

---

## Identifiants de connexion

**Mot de passe universel : `Cabinet2025!`**

### Médecins

| Login | Nom |
|-------|-----|
| `SM1542112` | Dr. Sophie Martin — Médecine générale |
| `PL8934567` | Dr. Paul Leroy — Cardiologie |
| `LN2367891` | Dr. Linh Nguyen — Pédiatrie |

### Secrétaires

| Login | Nom |
|-------|-----|
| `MD7891234` | Marie Dupont |
| `JB4563210` | Julien Bernard |

### Patients

| Login | Nom |
|-------|-----|
| `CD9012345` | Claire Durand |
| `JM3456789` | Jacques Moreau |
| `EP6781230` | Emma Petit |
| `LT1237896` | Luc Thomas |
| `IR8904561` | Isabelle Robert |
| `AS5670123` | Antoine Simon |

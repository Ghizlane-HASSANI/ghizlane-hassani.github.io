clear
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% EXERCICE 12 %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a = 0.431;
K = 4.2255e8;
gamma1 = 0.9;
gamma2 = 0.9;
minx = 1e3;
maxx = 1.1e7;

A1 = [a*(1-minx/K)  -gamma1*minx;
      0            -gamma2];
A2 = [a*(1-maxx/K)  -gamma1*maxx;
      0            -gamma2];

A = 0.5*(A1 + A2);
B = [0;1];
C = [1 0];
D = 0;

[Kp, Ki, Kd] = PIDBOSCHE(A,B,C,D);
[Kp1, Ki1, Kd1] = PIDBOSCHE(A1, B, C, D);
[Kp2, Ki2, Kd2] = PIDBOSCHE(A2, B, C, D);

% ===== Copie des gains pour Simulink =====
kp  = Kp;   ki  = Ki;   kd  = Kd;
kp1 = Kp1;  ki1 = Ki1;  kd1 = Kd1;
kp2 = Kp2;  ki2 = Ki2;  kd2 = Kd2;


out = sim('TP1.slx');

% Extraction des signaux
x     = out.x;        % tumeur simulée
xref  = out.xref;     % consigne
t     = out.tps;     % temps

% Erreur de suivi
e = xref - x;

% Erreur quadratique EMC0
EMC12= trapz(t, e.^2)

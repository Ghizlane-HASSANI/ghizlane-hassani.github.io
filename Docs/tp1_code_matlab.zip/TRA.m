%%%%%%%%%%%% . TRACE GRAPHIQUE
ta=18;
REF=out.xref;
VC=out.vc;
X=out.x;
X2=X.*X;
CC=out.c;
TPS=out.tps;
subplot(2,2,1)
plot(TPS,REF,'k','LineWidth',3)
ax = gca;
ax.XAxis.FontSize = ta; % taille des tick labels de l'axe X
ax.YAxis.FontSize = ta; % taille des tick labels de l'axe Y
grid on
legend('Référence','FontSize', 22)
xlabel('Temps (Jours)', 'FontSize', 16)
ylabel('Évolution de référence (nbre cellules)', 'FontSize', 16)
subplot(2,2,2)
plot(TPS,VC,'k','LineWidth',3)
ay = gca;
ay.XAxis.FontSize = ta; % taille des tick labels de l'axe X
ay.YAxis.FontSize = ta; % taille des tick labels de l'axe Y
grid on
legend('Vc','FontSize', 22)
xlabel('Temps (Jours)', 'FontSize', 20)
ylabel('Traitement chimio (doses)', 'FontSize', 20)
subplot(2,2,3)
plot(TPS,X,'k','LineWidth',3)
az = gca;
az.XAxis.FontSize = ta; % taille des tick labels de l'axe X
az.YAxis.FontSize = ta; % taille des tick labels de l'axe Y
grid on
legend('X','FontSize', 22)
xlabel('Temps (Jours)', 'FontSize', 16)
ylabel('Nombre de cellules', 'FontSize', 16)
subplot(2,2,4)
plot(TPS,CC,'k','LineWidth',3)
aw = gca;
aw.XAxis.FontSize = ta; % taille des tick labels de l'axe X
aw.YAxis.FontSize = ta; % taille des tick labels de l'axe Y
grid on
legend('C','FontSize', 22)
xlabel('Temps (Jours)', 'FontSize', 16)
ylabel('Concentration chimio', 'FontSize', 16)

